# Roadmap

This page lists **planned** work for Chronica Engine. Items not listed here are either already implemented or out of scope.

## Implemented (current)

- State-driven fragment selection with priority and conditions
- Turn resolution with choice actions and fragment effects
- Expression evaluation (`instability`, `memory.*`, `variables.*`)
- JSON save/load with backward-compatible legacy fields
- `FragmentLoader` for recursive `.tres` loading
- `ChronicaSession` high-level API
- `ChronicaEventBus` on sessions
- Module system (`ChronicaModule`)
- Chronica modules: `InstabilityManager`, `EchoManager`
- Headless smoke tests in `tests/smoke_test.gd`

## Planned

### Content authoring

- **EchoDefinition `.tres` loading** — load echo definitions from resource files (today echoes are registered in code via `register_echo()`)
- **Fragment validation tool** — editor script or headless checker for broken conditions, missing location ids, and orphan fragments

### State and migration

- **Legacy field migration guide** — documented path from `instability` / `memory` to `variables.*`
- **Optional auto-sync** — module or utility to mirror legacy fields into `variables` during transition

### Module system

- **Module registry** — register modules by name on `ChronicaSession` for save/load restoration without manual re-setup
- **Module serialization hooks** — `on_session_save` / `on_session_load` beyond `variables` persistence

### Engine quality

- **Expanded expression support** — typed comparisons, string operations (still no compound boolean expressions)
- **FragmentStore queries** — list all valid fragments at a location without selecting one (for debugging and UI previews)

### Documentation and examples

- **Example game scene** — minimal playable UI demo (not a visual editor)
- **Module template** — starter `ChronicaModule` project structure

## Out of scope (not planned)

The following are **not** on the roadmap:

- Visual fragment editor
- Multiplayer / networked sessions
- Analytics or telemetry pipeline
- AI-generated narrative content
- Built-in dialogue UI widgets

Games bring their own UI and integrate via `ChronicaSession`.

## Versioning

The repository includes tagged releases (for example `v0.2.0`). Breaking changes to save format or public APIs will be noted in release tags and migration notes when they ship.

## Contributing

When adding features:

1. Keep core systems generic
2. Put Chronica-specific logic in `modules/chronica/`
3. Add headless tests to `tests/smoke_test.gd`
4. Update docs in `docs/` — document only what exists
