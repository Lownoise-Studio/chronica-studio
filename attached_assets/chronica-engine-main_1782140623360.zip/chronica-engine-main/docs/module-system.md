# Module System

Modules let you attach optional behavior to `ChronicaSession` without editing core engine code. A module is a `ChronicaModule` subclass registered with `session.add_module()`.

## Architecture role

```
Chronica Engine Core     ← fragments, turns, state, save/load
        ↓
ChronicaModule           ← your extension point
        ↓
Game UI                  ← displays text, handles input
```

Core systems stay generic. Game-specific or Chronica-specific logic lives in modules.

## ChronicaModule

Base class: `addons/chronica_engine/core/chronica_module.gd`

```gdscript
class_name ChronicaModule
extends RefCounted
```

### Lifecycle methods

| Method | When it runs |
|---|---|
| `initialize(session)` | Immediately on `add_module()` |
| `on_turn_resolved(...)` | After each resolved turn |
| `on_session_loaded(state)` | After `session.load()` succeeds |

All methods are empty by default — override what you need.

### Hook signatures

```gdscript
func initialize(session: ChronicaSession) -> void:
    pass


func on_turn_resolved(
    previous_state: ChronicaState,
    current_state: ChronicaState,
    choice: Choice,
    fragment: Fragment
) -> void:
    pass


func on_session_loaded(state: ChronicaState) -> void:
    pass
```

`on_turn_resolved` receives the pre-turn and post-turn state copies from `TurnResolver`. Modify **`session.state`** to persist changes — the `current_state` parameter is a snapshot.

## Register a module

```gdscript
var session := ChronicaSession.new()
add_child(session)

session.add_module(MyModule.new())
session.load_fragments("res://fragments")
session.start("chapel_interior")
```

`initialize()` runs during `add_module()`, before `start()` if you register early enough.

### Module priority

Each module has a `priority: int` field (default `0`). On `on_turn_resolved`, `ChronicaSession` invokes modules in **ascending** priority order (lower runs first). Modules with equal priority keep their `add_module()` registration order.

Use priority when one module writes `variables.*` keys that another module reads on the same turn. Without an explicit priority difference, execution order is registration order only.

Built-in example defaults:

| Module | Default priority | Runs |
|---|---|---|
| `InstabilityManager` | `0` | First — increments `variables.instability` |
| `EchoManager` | `10` | After writers — evaluates echo conditions |

## Example: custom module

```gdscript
class_name TrustTracker
extends ChronicaModule

var _session: ChronicaSession


func initialize(session: ChronicaSession) -> void:
    _session = session
    session.event_bus.subscribe("choice_selected", _on_choice_selected)


func _on_choice_selected(payload: Variant) -> void:
    if _session.state == null:
        return
    _session.state.add_var("choices_made", 1)


func on_session_loaded(state: ChronicaState) -> void:
    if state.get_var("choices_made", null) == null:
        state.set_var("choices_made", 0)
```

```gdscript
session.add_module(TrustTracker.new())
```

## Event bus integration

Modules can subscribe during `initialize()`:

```gdscript
func initialize(session: ChronicaSession) -> void:
    _session = session
    _session.event_bus.subscribe("fragment_changed", _on_fragment_changed)


func _on_fragment_changed(fragment: Fragment) -> void:
    print("Now showing: ", fragment.text)
```

### Session events (from core)

| Event | Payload |
|---|---|
| `session_started` | `{ "location": String, "fragment": Fragment }` |
| `choice_selected` | `{ "choice": Choice, "fragment": Fragment }` |
| `fragment_changed` | `Fragment` |
| `state_changed` | `ChronicaState` |
| `session_loaded` | `ChronicaState` |

Modules may emit custom events on `session.event_bus` — see `EchoManager` for an example.

## Module design rules

Modules should:

- Read and write only `state.variables`
- Subscribe to events through `session.event_bus`
- Avoid direct references to other modules
- Avoid modifying engine core classes

If multiple modules need to communicate, they should do so through **state** or **events** — not by calling each other directly.

Additional guidelines:

- **Store the session reference** in `initialize()` for later hooks
- **Check for null** — `fragment` may be null; `session.state` may be null before `start()`
- **Reload module state** in `on_session_loaded()` when persisting data in `variables`
- **Re-register modules after load** — `session.load()` restores state, not module instances

## Module vs. game UI

| Layer | Responsibility |
|---|---|
| Game UI | Display text, render choices, call `session.choose()` |
| Modules | React to turns, manage meta-systems, emit events |
| Core | Fragment selection, expression evaluation, serialization |

The UI should not call `FragmentStore`, `TurnResolver`, or `ExpressionEvaluator` directly — use `ChronicaSession`.

## Chronica-specific modules (optional examples)

Built-in example modules live in `addons/chronica_engine/modules/chronica/`:

- `InstabilityManager`
- `EchoManager`

These demonstrate how to build on `ChronicaModule`. **You do not need them** for your game. See [Chronica modules](chronica-modules.md) and [Example module ideas](chronica-modules.md#example-module-ideas).

## Testing a module

```gdscript
var session := ChronicaSession.new()
add_child(session)

session.add_module(MyModule.new())
# add test fragments, start, choose, assert on session.state
```

See `_run_instability_manager_test()` and `_run_echo_manager_test()` in `tests/smoke_test.gd`.
