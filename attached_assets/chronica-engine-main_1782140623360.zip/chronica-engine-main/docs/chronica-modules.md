# Chronica Modules

Chronica-specific modules live in `addons/chronica_engine/modules/chronica/`. They extend `ChronicaModule` and demonstrate narrative systems built on the generic engine.

**These modules are examples, not requirements.** The core engine works without them. Games can use zero Chronica modules, pick one as a starting point, or write entirely custom modules for any genre.

**Engine core stays generic.** Example modules only read and write `state.variables`.

## Module design rules

Modules should:

- Read and write only `state.variables`
- Subscribe to events through `session.event_bus`
- Avoid direct references to other modules
- Avoid modifying engine core classes

If multiple modules need to communicate, they should do so through state or events.

See [Module system](module-system.md) for the full module API.

## InstabilityManager

Path: `modules/chronica/instability_manager.gd`

Example module that tracks rising instability across turns using the generic variables system.

### Behavior

On each resolved turn with a valid fragment:

1. `variables.instability += 1`
2. When `variables.instability >= 10`, sets `variables.reality_phase = 1`

### Usage

```gdscript
session.add_module(InstabilityManager.new())
```

No configuration required. The module stores nothing outside `state.variables`.

### Example progression

| Turn | `variables.instability` | `variables.reality_phase` |
|---|---|---|
| 0 | (unset / 0) | (unset) |
| 1 | 1 | (unset) |
| … | … | (unset) |
| 10 | 10 | 1 |

`variables.reality_phase` is an example milestone flag derived from `variables.instability`. It is **not** a migration of the legacy top-level `reality_layer` field — those names are similar but the concepts are independent. See [State and variables — Legacy vs. module variables](state-and-variables.md#legacy-vs-module-variables).

### Fragment integration

Reference instability in fragment conditions:

```
variables.instability >= 3
```

Pair with `InstabilityManager` or your own module that writes `variables.instability`.

## EchoManager

Path: `modules/chronica/echo_manager.gd`

Example module that manages **Echoes** — state-driven narrative anomalies with a four-stage lifecycle.

### EchoDefinition

Path: `modules/chronica/echo_definition.gd`

```gdscript
class_name EchoDefinition
extends Resource
```

| Property | Purpose |
|---|---|
| `id` | Unique echo id |
| `activation_conditions` | All must pass to leave DORMANT |
| `manifestation_conditions` | All must pass to leave ACTIVE |
| `resolution_conditions` | All must pass to leave MANIFESTED |
| `effects_on_activate` | Applied on activation |
| `effects_on_manifest` | Applied on manifestation |
| `effects_on_resolve` | Applied on resolution |

Conditions and effects use the same expression syntax as fragments (`variables.*`, `memory.*`).

### Lifecycle

```
DORMANT
   ↓
ACTIVE
   ↓
MANIFESTED
   ↓
RESOLVED
```

| State | Value | Transition when | Events emitted |
|---|---|---|---|
| DORMANT | 0 | `activation_conditions` pass | `echo_activated` |
| ACTIVE | 1 | `manifestation_conditions` pass | `echo_manifested` |
| MANIFESTED | 2 | `resolution_conditions` pass | `echo_resolved` |
| RESOLVED | 3 | Terminal state | — |

Only one transition per echo per turn evaluation.

### Persistence

Echo states are stored in:

```gdscript
state.variables.echoes = {
    "warden": 2   # MANIFESTED
}
```

Values are integers matching `EchoManager.EchoLifecycle`. States persist through save/load via `ChronicaSerializer`.

### Usage

```gdscript
var echo_manager := EchoManager.new()

var warden := EchoDefinition.new()
warden.id = "warden"
warden.activation_conditions = ["variables.instability >= 3"]
warden.manifestation_conditions = ["variables.instability >= 5"]
warden.resolution_conditions = ["variables.spoke_to_warden == true"]

echo_manager.register_echo(warden)
session.add_module(echo_manager)
```

### API

| Method | Description |
|---|---|
| `register_echo(echo)` | Register an `EchoDefinition` |
| `get_echo_state(id) -> int` | Current lifecycle int |

### Events

Subscribe via `session.event_bus`:

| Event | Payload |
|---|---|
| `echo_activated` | echo id (`String`) |
| `echo_manifested` | echo id (`String`) |
| `echo_resolved` | echo id (`String`) |

```gdscript
session.event_bus.subscribe("echo_manifested", func(id):
    print("Echo manifested: ", id)
)
```

### After loading a save

Re-create the manager, re-register echoes, then load:

```gdscript
var echo_manager := EchoManager.new()
echo_manager.register_echo(warden)
session.add_module(echo_manager)
session.load("user://save.json")
# echo_manager.get_echo_state("warden") restores from variables.echoes
```

`on_session_loaded()` reloads echo states from `state.variables.echoes`.

## Core vs. example modules

| | Engine core | Example modules |
|---|---|---|
| Location | `addons/chronica_engine/*.gd` | `modules/chronica/` |
| Purpose | Generic narrative engine | Reference implementations |
| State | `ChronicaState`, fragments, turns | `state.variables` only |
| Required | Yes | No |
| Examples | `FragmentStore`, `TurnResolver` | `InstabilityManager`, `EchoManager` |

## Combining example modules

```gdscript
session.add_module(InstabilityManager.new())  # priority 0 — runs first

var echo_manager := EchoManager.new()       # priority 10 — runs after writers
echo_manager.register_echo(warden)
session.add_module(echo_manager)

session.load_fragments("res://fragments")
session.start("chapel_interior")
```

`InstabilityManager` increments `variables.instability` each turn. `EchoManager` evaluates echo conditions against the same variables — they communicate through **state**, not direct references.

Registration order does not matter when using the built-in modules: `InstabilityManager` defaults to priority `0` and `EchoManager` to `10`, so instability is incremented before echo lifecycle runs on the same turn. If you write custom modules with same-turn dependencies, set `priority` explicitly (lower runs first). See [Module system — Module priority](module-system.md#module-priority).

## Tests

See `tests/smoke_test.gd`:

- `_run_instability_manager_test()` — core without modules vs. with manager
- `_run_echo_manager_test()` — full warden echo lifecycle and save/load

Run headlessly:

```bash
godot --path /path/to/project --headless
```

## Example module ideas

Chronica Engine is not limited to Chronica-style games.

Examples:

- Detective game → `SuspicionManager`
- Political simulator → `InfluenceManager`
- Dating sim → `RelationshipManager`
- Survival game → `HungerManager`
- Horror game → `SanityManager`

All use the same core engine APIs:

- `ChronicaModule`
- `ChronicaSession`
- `ChronicaEventBus`
- `state.variables`

Pick a pattern from the example modules, rename the variables, and write conditions in your fragments against `variables.*`. The engine does not care what genre your game is.
