# Getting Started

This guide walks through setting up Chronica Engine and running a minimal narrative session.

## Enable the addon

1. Copy or clone the project with `addons/chronica_engine/`
2. Open the project in Godot 4
3. Go to **Project → Project Settings → Plugins**
4. Enable **Chronica Engine**

Open the editor once so Godot registers global `class_name` scripts.

## Create a session

`ChronicaSession` is a `Node`. Add it to your scene tree:

```gdscript
extends Node

var session: ChronicaSession


func _ready() -> void:
    session = ChronicaSession.new()
    add_child(session)

    _start_game()


func _start_game() -> void:
    session.load_fragments("res://fragments")
    var fragment := session.start("chapel_interior")
    _show_fragment(fragment)
```

`add_child()` is required so the session's internal `TurnResolver` node initializes in `_ready()`.

## Load fragments

Place `.tres` fragment files under a directory (see [Authoring fragments](authoring-fragments.md)), then:

```gdscript
var count := session.load_fragments("res://fragments")
print("Loaded %d fragments" % count)
```

`load_fragments()` uses `FragmentLoader.load_directory()` internally and adds all loaded fragments to the session store.

## Start at a location

```gdscript
var fragment := session.start("chapel_interior")
```

This:

1. Creates a new `ChronicaState` if one does not exist
2. Sets `state.location` to `"chapel_interior"`
3. Selects and returns the active `Fragment`
4. Emits `fragment_changed`, `state_changed`, and event bus events

Display `fragment.text` and build UI buttons from `fragment.choices`.

## Make a choice

```gdscript
func _on_choice_pressed(choice: Choice) -> void:
    var fragment := session.choose(choice)
    _show_fragment(fragment)
```

`choose()` resolves the action, updates state, selects the next fragment, applies fragment effects, notifies modules, and emits events.

## Add a module (optional)

Modules are not required. Register your own `ChronicaModule` subclass when you need game-specific systems:

```gdscript
session.add_module(SuspicionManager.new())
```

The bundled `InstabilityManager` and `EchoManager` are example implementations — see [Chronica modules](chronica-modules.md).

Register modules **before** `start()` if they need to hook into the first turn, or at any time before the relevant lifecycle event.

## Save and load

```gdscript
session.save("user://save.json")

# Later, on a new session:
session.load("user://save.json")
var fragment := session.get_current_fragment()
```

Default path is `user://save.json`. Saves are JSON via `ChronicaSerializer`.

After loading, re-register modules and echo definitions that your game needs — module runtime state in `state.variables` is restored, but module instances must be set up again.

## Listen for events

```gdscript
func _ready() -> void:
    session = ChronicaSession.new()
    add_child(session)

    session.event_bus.subscribe("fragment_changed", _on_fragment_changed)
    session.fragment_changed.connect(_on_fragment_changed_signal)


func _on_fragment_changed(fragment: Fragment) -> void:
    _show_fragment(fragment)
```

### Session event bus events

| Event | Payload | When |
|---|---|---|
| `session_started` | `{ "location": String, "fragment": Fragment }` | `start()` |
| `choice_selected` | `{ "choice": Choice, "fragment": Fragment }` | `choose()` |
| `fragment_changed` | `Fragment` | `start()`, `choose()` |
| `state_changed` | `ChronicaState` | `start()`, `choose()`, `load()` |
| `session_loaded` | `ChronicaState` | `load()` |

## Minimal UI pattern

Your game UI should only use `ChronicaSession` — not `FragmentStore`, `TurnResolver`, or `ChronicaSerializer` directly.

```gdscript
func _show_fragment(fragment: Fragment) -> void:
    if fragment == null:
        return
    $TextLabel.text = fragment.text
    _clear_choice_buttons()
    for choice in fragment.choices:
        var button := Button.new()
        button.text = choice.label
        button.pressed.connect(func(): _on_choice_pressed(choice))
        $ChoiceContainer.add_child(button)
```

## Run tests

Verify the engine from the command line:

```bash
godot --path /path/to/chronica-engine-godot --headless
```

See `tests/smoke_test.gd` for working examples of sessions, modules, serialization, and fragment loading.

## Next steps

- [Authoring fragments](authoring-fragments.md) — create `.tres` narrative content
- [State and variables](state-and-variables.md) — conditions, effects, and save data
- [Chronica modules](chronica-modules.md) — example modules (optional)
