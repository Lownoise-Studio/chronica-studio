# Authoring Fragments

Fragments are `Resource` files that define what the player sees and can do at a location. Each fragment belongs to a location id and competes with other fragments at that location via priority and conditions.

## Fragment properties

| Property | Type | Description |
|---|---|---|
| `id` | `String` | Location id (must match `state.location`) |
| `priority` | `int` | Higher value wins when multiple fragments are valid |
| `conditions` | `Array[String]` | All must pass (empty = always valid) |
| `effects` | `Array[String]` | Applied when fragment becomes active after a turn |
| `text` | `String` | Narrative body text |
| `choices` | `Array[Choice]` | Player options |

## Choice properties

| Property | Type | Description |
|---|---|---|
| `label` | `String` | Button or menu text |
| `action` | `String` | Resolved by `ActionResolver` when chosen |

### Action examples

```
goto:library
variables.trust += 1
variables.met_warden = true
variables.tension += 1
```

An empty action string is valid and does nothing.

> **Legacy syntax (supported for backward compatibility):** `instability += 1` — use `variables.instability += 1` in new fragments.

## Fragment selection

When the engine needs the active fragment for a location:

1. Find fragments where `id == state.location`
2. Keep fragments whose conditions all pass
3. Pick the one with the highest `priority`

When multiple fragments have the same id and same priority, Chronica Engine breaks ties deterministically by id, then text. For fragments with the same location id, this means the alphabetically earliest text wins. If you want multiple variants to be meaningfully reachable, give them distinct priorities or distinct conditions.

Example: a normal chapel fragment at priority `0` and a broken variant at priority `100` with condition `variables.tension >= 3`. At tension 2, the normal fragment wins. At tension 3+, the broken variant wins.

## Conditions and effects syntax

See [State and variables](state-and-variables.md) for supported expression formats. Each condition or effect is a single simple expression — no `and` / `or` inside one string.

Use multiple entries in `conditions` for AND logic:

```
conditions = ["variables.tension >= 3", "memory.visited_chapel == true"]
```

Use multiple fragments for OR logic.

## Validation

`FragmentValidator.validate_fragments()` checks authored content before runtime.

- **Errors** mean content cannot safely run (invalid syntax, missing ids, bad goto targets).
- **Warnings** mean content may be unreachable or fragile.

Legacy paths `instability` and `reality_layer` remain valid at runtime. The validator emits `LEGACY_SYNTAX` with the message: "Supported legacy path. Prefer variables.* for new content." It does not warn on `location`, `memory.*`, or `variables.*`. Note: `variables.reality_phase` (from `InstabilityManager`) is not the replacement for `reality_layer` — see [Legacy vs. module variables](state-and-variables.md#legacy-vs-module-variables).

## Create a fragment in the editor

1. In the FileSystem dock, right-click → **New Resource**
2. Search for **Fragment** (requires the addon enabled)
3. Set properties in the Inspector
4. Save as `.tres`

For choices, create **Choice** sub-resources or embed them in the `.tres` file.

## Example `.tres` file

```tres
[gd_resource type="Resource" script_class="Fragment" load_steps=3 format=3]

[ext_resource type="Script" path="res://addons/chronica_engine/fragment.gd" id="1_fragment"]
[ext_resource type="Script" path="res://addons/chronica_engine/choice.gd" id="2_choice"]

[sub_resource type="Resource" id="Choice_disturb"]
script = ExtResource("2_choice")
label = "Disturb the silence"
action = "variables.tension += 1"

[resource]
script = ExtResource("1_fragment")
id = "chapel_interior"
priority = 0
conditions = Array[String]([])
effects = Array[String]([])
text = "The chapel stands intact, candles flickering softly."
choices = Array[ExtResource("2_choice")]([SubResource("Choice_disturb")])
```

A higher-priority variant with a condition:

```tres
[resource]
script = ExtResource("1_fragment")
id = "chapel_interior"
priority = 100
conditions = Array[String](["variables.tension >= 3"])
effects = Array[String]([])
text = "The chapel is broken, stone cracked and candles extinguished."
choices = Array[Resource]([])
```

> **Note:** Some test fixtures under `tests/fixtures/` use legacy syntax (`instability >= 3`) for backward-compatibility smoke tests. New content should use `variables.*`.

## Directory layout

Organize fragments by location or chapter:

```
res://fragments/
├── chapel/
│   ├── chapel_normal.tres
│   └── chapel_broken.tres
└── library/
    └── library_intro.tres
```

Load recursively:

```gdscript
session.load_fragments("res://fragments")
```

`FragmentLoader` scans subdirectories, loads only valid `Fragment` `.tres` files, and ignores other files.

## Load a single fragment

```gdscript
var fragment := FragmentLoader.load_fragment("res://fragments/chapel/chapel_normal.tres")
if fragment != null:
    session.store.add(fragment)
```

Normally you load entire directories via `session.load_fragments()`.

## Authoring tips

- **One location id per scene area** — `id` is the location key, not a unique fragment name
- **Use priority for variants** — calm vs. broken vs. secret versions of the same place
- **Keep actions small** — choice actions change state; fragment effects apply on arrival
- **Prefer `variables.*`** for new content — see [State and variables](state-and-variables.md)
- **Test conditions headlessly** — see `tests/smoke_test.gd` for patterns

## When effects run

Fragment `effects` run **after** the choice action resolves and the fragment is selected — not when the player merely sees the fragment from `start()`. Choice `action` strings run first via `ActionResolver`.

Turn order:

1. Choice action
2. Fragment selection
3. Fragment effects
