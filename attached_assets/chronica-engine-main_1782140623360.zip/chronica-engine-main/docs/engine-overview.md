# Engine Overview

This page describes how Chronica Engine works internally. Game code normally interacts through `ChronicaSession` rather than these lower-level classes.

## Core components

### ChronicaState

Holds all narrative state:

- `location` — current location id (matches `Fragment.id`)
- `variables` — generic key/value state (preferred for new work)
- `memory` — legacy dictionary for story flags
- `instability`, `reality_layer` — legacy Chronica-specific fields kept for backward compatibility

Use `get_var()`, `set_var()`, and `add_var()` for `variables`.

### Fragment

A narrative unit at a location. Each fragment has:

| Property | Purpose |
|---|---|
| `id` | Location id this fragment belongs to |
| `priority` | Higher priority wins when multiple fragments match |
| `conditions` | All must pass for the fragment to be valid |
| `effects` | Applied when the fragment becomes active after a turn |
| `text` | Narrative text to display |
| `choices` | Player options |

### FragmentStore

Stores fragments and selects the active one:

1. Match fragments where `fragment.id == state.location`
2. Filter to fragments whose conditions pass
3. Sort by `priority` descending
4. Return the highest-priority valid fragment

There is no OR logic inside a single condition string. Use multiple fragments or multiple condition strings (all must pass).

### TurnResolver

Resolves one player choice:

1. Duplicate the previous state (for signals and modules)
2. Resolve the choice action via `ActionResolver`
3. Update state fields from the working copy
4. Select the active fragment for the current location
5. Apply that fragment's effects
6. Emit `turn_resolved` (used by modules)

### ActionResolver

Parses choice action strings:

| Action | Example |
|---|---|
| Go to location | `goto:chapel_interior` |
| Increment | `variables.trust += 1` |
| Assignment | `variables.phase = "dream"` |
| No-op | `""` (empty string) |

> **Legacy syntax (supported for backward compatibility):** `instability += 1` — prefer `variables.*` for new content.

### ExpressionEvaluator

Evaluates condition and effect strings on `ChronicaState`. Supports simple comparisons and assignments only — no compound boolean expressions.

**Recommended syntax** — use `variables.*` and `memory.*`:

```
variables.tension >= 3
variables.phase == "dream"
memory.visited_chapel == true
```

```
variables.tension += 1
variables.phase = "dream"
memory.visited_chapel = true
memory.trust += 1
```

> **Legacy syntax (supported for backward compatibility):**
> ```
> instability >= 3
> reality_layer == 1
> instability += 1
> ```
> Prefer `variables.*` for new content. Legacy top-level fields remain for older fragments and saves.

### ChronicaSession

The main entry point for games. Owns:

- `state` — current `ChronicaState`
- `store` — `FragmentStore`
- `resolver` — `TurnResolver` (child node)
- `serializer` — `ChronicaSerializer` instance
- `event_bus` — `ChronicaEventBus`

Also exposes Godot signals: `fragment_changed`, `state_changed`, `session_loaded`.

### ChronicaSerializer

Serializes state to JSON:

- Saves: `location`, `instability`, `reality_layer`, `memory`, `variables`
- Loads older saves that lack `variables` as an empty dictionary

### FragmentLoader

Loads `Fragment` resources from `.tres` files. Recursively scans directories, ignores invalid files, returns fragments sorted by priority descending.

### ChronicaEventBus

Pub/sub event bus on the session. Session emits lifecycle events; modules may emit their own (for example, `EchoManager` emits echo events).

## Turn flow

```
Player selects choice
        ↓
ChronicaSession.choose(choice)
        ↓
TurnResolver.resolve()
        ↓
ActionResolver.resolve(choice.action)   ← update location, variables, etc.
        ↓
FragmentStore.get_active_fragment()     ← pick highest-priority valid fragment
        ↓
Fragment.apply_effects()              ← apply fragment effects
        ↓
Modules.on_turn_resolved()            ← optional module hooks
        ↓
Session emits fragment_changed, state_changed, event_bus events
        ↓
Return Fragment to game UI
```

## Module layer

Modules extend `ChronicaModule` and register on the session with `add_module()`. They receive:

- `initialize(session)` — setup, subscribe to events
- `on_turn_resolved(...)` — after each resolved turn
- `on_session_loaded(state)` — after a save is loaded

Modules should modify `session.state` (especially `state.variables`) rather than patching core classes.

## File layout

```
addons/chronica_engine/
├── chronica_session.gd
├── chronica_state.gd
├── chronica_serializer.gd
├── fragment.gd
├── fragment_store.gd
├── fragment_loader.gd
├── turn_resolver.gd
├── action_resolver.gd
├── expression_evaluator.gd
├── choice.gd
├── core/
│   ├── chronica_module.gd
│   └── chronica_event_bus.gd
└── modules/chronica/
    ├── instability_manager.gd
    ├── echo_manager.gd
    └── echo_definition.gd
```
