# Chronica Engine

> ⚠️ Chronica Engine is currently in alpha (`v1.0.0-alpha`). APIs may change as the engine evolves.

A modular Godot 4 narrative engine for state-driven storytelling, reusable game systems, and interactive fiction.

Chronica Engine is a Godot 4 addon that provides a **state-driven narrative engine** for interactive fiction and narrative games. It manages locations, fragments, choices, state variables, save/load, and optional game-specific modules.

## Design philosophy

Chronica Engine keeps narrative rules separate from game-specific mechanics.

Core systems handle:

* State management
* Fragment selection
* Turn resolution
* Persistence
* Events

Game-specific behavior lives in optional modules.

This allows the same engine to power many types of games without modifying core code.

## Architecture

```text
Godot
  ↓
Chronica Engine Core
  ↓
Modules
  ↓
Game
```

Your game UI should talk primarily to **`ChronicaSession`**.

Core systems handle fragment selection, turn resolution, serialization, and events.

Optional **modules** add game-specific behavior without modifying core code.

The bundled Chronica modules (`InstabilityManager`, `EchoManager`) are **examples**, not requirements.

## Use cases

Chronica Engine is designed for:

* Interactive fiction
* Visual novels
* Choice-driven RPGs
* Mystery and detective games
* Narrative horror experiences
* Dating simulations
* Branching dialogue systems

## Installation

1. Copy `addons/chronica_engine/` into your project's `addons/` directory.
2. Open the project in Godot 4.
3. Go to **Project → Project Settings → Plugins**.
4. Enable **Chronica Engine**.

## Documentation index

| Document                                           | Description                                                      |
| -------------------------------------------------- | ---------------------------------------------------------------- |
| [Engine overview](docs/engine-overview.md)         | Core systems and turn flow                                       |
| [Getting started](docs/getting-started.md)         | Install the addon and run a session                              |
| [Authoring fragments](docs/authoring-fragments.md) | Write `.tres` fragment resources                                 |
| [State and variables](docs/state-and-variables.md) | `ChronicaState`, memory, and expressions                         |
| [Module system](docs/module-system.md)             | Create custom `ChronicaModule` classes                           |
| [Chronica modules](docs/chronica-modules.md)       | Example modules (`InstabilityManager`, `EchoManager`) — optional |
| [Roadmap](docs/roadmap.md)                         | Planned features                                                 |

## Core systems

These classes live in `addons/chronica_engine/`:

| Class                | Role                                                          |
| -------------------- | ------------------------------------------------------------- |
| `ChronicaState`      | Narrative state (location, variables, memory)                 |
| `Fragment`           | A narrative block with conditions, effects, text, and choices |
| `Choice`             | A player option with a label and action string                |
| `FragmentStore`      | Holds fragments and selects the active one                    |
| `TurnResolver`       | Resolves a choice into state changes and a new fragment       |
| `ChronicaSession`    | High-level API for games                                      |
| `ChronicaSerializer` | JSON save/load for `ChronicaState`                            |
| `FragmentLoader`     | Load `Fragment` resources from `.tres` files                  |
| `ChronicaEventBus`   | Pub/sub events on the session                                 |

## Public APIs for games

Use these from your game code:

* **`ChronicaSession`** — start, choose, save, load, modules, and events
* **`FragmentLoader`** — load fragment directories (usually via `session.load_fragments()`)
* **`ChronicaSerializer`** — direct save/load (usually via `session.save()` / `session.load()`)
* **`ChronicaModule`** — base class for custom modules
* **`ChronicaEventBus`** — subscribe via `session.event_bus`
* **`InstabilityManager`** — example module (Chronica-style instability tracking)
* **`EchoManager`** — example module (Chronica-style echo lifecycle)

You do not need either Chronica module to use the engine.

See [Example module ideas](docs/chronica-modules.md#example-module-ideas).

## Quick example

```gdscript
var session := ChronicaSession.new()
add_child(session)

session.load_fragments("res://fragments")

var fragment := session.start("chapel_interior")

# Display fragment.text and fragment.choices in your UI

var choice: Choice = fragment.choices[0]
fragment = session.choose(choice)
```

Optionally register modules before `start()`:

```gdscript
session.add_module(SuspicionManager.new())
```

Custom modules can implement any game-specific system by extending `ChronicaModule`.

## Requirements

* Godot 4.x (tested with 4.7)

## Tests

Headless smoke tests live in `tests/smoke_test.gd`.

Run:

```bash
godot --path /path/to/project --headless
```

## Roadmap

### v1.1.0 — Content Tooling

* FragmentValidator
* ContentLinter
* FragmentEditor

See the full roadmap in [docs/roadmap.md](docs/roadmap.md).
