# State and Variables

Narrative progress is stored in `ChronicaState`. Games read and mutate state through the session (`session.state`) and through fragment conditions, effects, and choice actions.

## ChronicaState fields

| Field | Type | Description |
|---|---|---|
| `location` | `String` | Current location id |
| `variables` | `Dictionary` | Generic narrative state (**preferred**) |
| `memory` | `Dictionary` | Legacy story flags |
| `instability` | `int` | Legacy Chronica field (see [Legacy vs. module variables](#legacy-vs-module-variables)) |
| `reality_layer` | `int` | Legacy Chronica field (see [Legacy vs. module variables](#legacy-vs-module-variables)) |

New content should use `variables`. Legacy fields remain for backward compatibility with existing fragments and saves.

## Variables API

```gdscript
state.set_var("tension", 2)
state.add_var("tension", 1)       # tension becomes 3
var tension = state.get_var("tension", 0)
```

Modules and fragments can also modify variables through expression strings (see below).

## Memory vs. variables

Both are dictionaries. The engine treats them identically in expressions, but they are separate namespaces:

```
memory.visited_chapel == true    # reads state.memory["visited_chapel"]
variables.tension >= 3           # reads state.variables["tension"]
```

Prefer `variables` for new work. Use `memory` only when maintaining existing content.

## Expression syntax

`ExpressionEvaluator` powers fragment conditions, fragment effects, and choice actions (via `ActionResolver`).

### Supported condition operators

`>=`, `<=`, `==`, `!=`, `>`, `<`

### Supported paths

| Path | Reads/writes |
|---|---|
| `variables.<key>` | `state.variables` (**preferred**) |
| `memory.<key>` | `state.memory` |
| `location` | Assignment only in effects |
| `instability` | Legacy field |
| `reality_layer` | Legacy field |

### Condition examples (recommended)

```
variables.tension >= 3
variables.phase == "dream"
memory.visited_chapel == true
```

### Effect examples (recommended)

```
variables.tension += 1
variables.phase = "dream"
variables.spoke_to_warden = true
memory.visited_chapel = true
memory.trust += 1
```

> **Legacy syntax (supported for backward compatibility):**
> ```
> instability >= 3
> reality_layer == 1
> instability += 1
> ```
> These paths remain valid at runtime. `FragmentValidator` warns with `LEGACY_SYNTAX` but does not treat them as errors. Prefer `variables.instability` for new content instead of bare `instability`. For `reality_layer`, pick an explicit `variables.*` key for your game — there is no built-in migration target (see [Legacy vs. module variables](#legacy-vs-module-variables)).

### Limitations

- **No compound boolean expressions** — one comparison per string
- **AND** — list multiple conditions on a fragment
- **OR** — use multiple fragments with different priorities/conditions
- **Increments** — integer amounts only (`+= 1`, `+= -2`)

## Choice actions

Choice `action` strings use the same effect syntax, plus:

```
goto:library
```

`goto:<location_id>` sets `state.location` to move the player.

## State duplication

`duplicate_state()` deep-copies `memory` and `variables`. Turn resolution uses duplicates internally for module hooks and signals.

## Serialization

`ChronicaSerializer` saves state as JSON:

```json
{
  "location": "chapel_interior",
  "instability": 3,
  "reality_layer": 1,
  "memory": {
    "visited_chapel": true
  },
  "variables": {
    "tension": 3,
    "phase": "dream",
    "echoes": {
      "warden": 2
    }
  }
}
```

Top-level `instability` and `reality_layer` are legacy save fields. New module and fragment logic should live in `variables`.

### Save and load

```gdscript
ChronicaSerializer.save_state(session.state, "user://save.json")
var loaded := ChronicaSerializer.load_state("user://save.json")
```

Or via the session:

```gdscript
session.save("user://save.json")
session.load("user://save.json")
```

### Backward compatibility

Saves without a `variables` key load with `variables = {}`. Legacy top-level fields (`instability`, `reality_layer`, `memory`) are always preserved.

Nested dictionaries inside `variables` (for example `variables.echoes`) are saved and restored as JSON objects.

## Legacy vs. module variables

Top-level `instability` and `reality_layer` are independent legacy save fields. They are **not** automatically synced with `state.variables`.

`variables.reality_phase` (set by the example `InstabilityManager` when `variables.instability >= 10`) is **not** a migrated replacement for legacy `reality_layer`. Despite the similar names, they are unrelated:

| | `reality_layer` (legacy) | `variables.reality_phase` (module) |
|---|---|---|
| Storage | Top-level `ChronicaState` field | Entry in `state.variables` |
| Set by | Fragment expressions / saves | `InstabilityManager` from `variables.instability` |
| Meaning | Original Chronica layered-reality counter (game-specific) | Example instability milestone flag |

No engine code reads or writes both together, derives one from the other, or treats them as interchangeable. New games should use explicit `variables.*` keys rather than assuming `reality_phase` replaces `reality_layer`.

## Module state in variables

Chronica modules store runtime data in `state.variables`:

| Module | Variable | Example |
|---|---|---|
| `InstabilityManager` | `variables.instability` | Incremented each turn |
| `InstabilityManager` | `variables.reality_phase` | Set to `1` at instability 10 |
| `EchoManager` | `variables.echoes` | `{ "warden": 2 }` lifecycle ints |

See [Chronica modules](chronica-modules.md) for details.

## Inspecting state in game code

```gdscript
print(session.state.location)
print(session.state.get_var("tension", 0))
print(session.state.memory.get("visited_chapel", false))
```

After `choose()`, read updated values from `session.state` — the session mutates state in place.

## Testing expressions

```gdscript
var state := ChronicaState.new()
state.set_var("tension", 2)

ExpressionEvaluator.apply_effect("variables.tension += 1", state)
assert(state.get_var("tension") == 3)

assert(ExpressionEvaluator.evaluate_condition("variables.tension >= 3", state))
```

See `_run_variables_test()` in `tests/smoke_test.gd` for a full example.
