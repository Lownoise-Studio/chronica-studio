extends Node


func _ready() -> void:
	_run_smoke_test()
	_run_serializer_test()
	_run_variables_test()
	_run_instability_mirror_test()
	_run_fragment_loader_test()
	_run_fragment_ordering_test()
	_run_session_test()
	_run_instability_manager_test()
	_run_event_bus_test()
	_run_echo_manager_test()
	_run_echo_manager_extended_test()
	_run_module_order_test()
	_run_atomic_turn_regression_test()
	_run_fragment_validator_test()
	get_tree().quit()


func _run_smoke_test() -> void:
	var store := FragmentStore.new()

	var normal_fragment := Fragment.new()
	normal_fragment.id = "chapel_interior"
	normal_fragment.priority = 0
	normal_fragment.text = "The chapel stands intact, candles flickering softly."
	normal_fragment.choices = [
		Choice.new("Disturb the silence", "instability += 1"),
	]

	var broken_fragment := Fragment.new()
	broken_fragment.id = "chapel_interior"
	broken_fragment.priority = 100
	broken_fragment.conditions = ["instability >= 3"]
	broken_fragment.text = "The chapel is broken, stone cracked and candles extinguished."

	store.add_all([normal_fragment, broken_fragment])

	var state := ChronicaState.new()
	state.location = "chapel_interior"
	state.set_var("instability", 2)

	var initial_fragment := store.get_active_fragment(state.location, state)
	assert(initial_fragment == normal_fragment, "Expected normal chapel fragment at instability 2")
	print("PASS: normal chapel fragment selected at instability 2")

	var turn_resolver := TurnResolver.new()
	var choice := normal_fragment.choices[0]
	var result_fragment := turn_resolver.resolve(choice, state, store)

	assert(state.instability == 3, "Expected instability 3 after choice, got %d" % state.instability)
	assert(state.get_var("instability") == 3, "Expected variables.instability 3 after legacy effect")
	print("PASS: instability increased to 3")

	assert(result_fragment == broken_fragment, "Expected broken chapel fragment after turn")
	print("PASS: broken chapel fragment selected after turn")

	assert(result_fragment.text == broken_fragment.text, "Expected broken chapel text")
	print("PASS: broken chapel text returned")

	print("\nAll smoke tests passed.")
	normal_fragment.choices = []
	if is_instance_valid(turn_resolver):
		turn_resolver.free()
	store = null
	state = null
	normal_fragment = null
	broken_fragment = null


func _run_serializer_test() -> void:
	var save_path := "user://test_save.json"
	var original := ChronicaState.new()
	original.location = "chapel_interior"
	original.set_var("instability", 3)
	original.reality_layer = 1
	original.memory = {
		"visited_chapel": true,
		"trust": 2,
	}
	original.variables = {
		"instability": 3,
		"tension": 3,
		"phase": "dream",
	}

	assert(ChronicaSerializer.save_state(original, save_path), "Expected save_state to succeed")
	print("PASS: state saved to user://test_save.json")

	var loaded := ChronicaSerializer.load_state(save_path)
	assert(loaded != null, "Expected load_state to return a ChronicaState")
	assert(loaded.location == original.location, "Expected location to match")
	assert(loaded.instability == original.instability, "Expected instability to match")
	assert(loaded.reality_layer == original.reality_layer, "Expected reality_layer to match")
	assert(loaded.memory == original.memory, "Expected memory to match")
	assert(loaded.variables == original.variables, "Expected variables to match")
	print("PASS: loaded state matches saved state")

	var legacy_save_path := "user://test_legacy_save.json"
	var legacy_data := {
		"location": "chapel_interior",
		"instability": 2,
		"reality_layer": 0,
		"memory": {"visited_chapel": true},
	}
	var legacy_file := FileAccess.open(legacy_save_path, FileAccess.WRITE)
	assert(legacy_file != null, "Expected legacy save file to open for writing")
	legacy_file.store_string(JSON.stringify(legacy_data, "\t"))
	legacy_file.close()
	var legacy_loaded := ChronicaSerializer.load_state(legacy_save_path)
	assert(legacy_loaded != null, "Expected legacy save to load")
	assert(legacy_loaded.get_var("instability", 0) == 2, "Expected legacy save to seed variables.instability")
	assert(legacy_loaded.instability == 2, "Expected legacy instability mirror to match seeded value")
	print("PASS: legacy save without variables loads correctly")

	var absolute_path := ProjectSettings.globalize_path(save_path)
	assert(DirAccess.remove_absolute(absolute_path) == OK, "Expected test save file deletion to succeed")
	assert(not FileAccess.file_exists(save_path), "Expected test save file to be deleted")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(legacy_save_path))
	print("PASS: test save file deleted")

	original = null
	loaded = null
	print("\nAll serializer tests passed.")


func _run_variables_test() -> void:
	var state := ChronicaState.new()
	state.set_var("tension", 2)

	ExpressionEvaluator.apply_effect("variables.tension += 1", state)
	assert(state.get_var("tension") == 3, "Expected variables.tension to be 3 after increment")
	print("PASS: variables.tension += 1 updated variables.tension")

	var store := FragmentStore.new()
	var normal_fragment := Fragment.new()
	normal_fragment.id = "tension_room"
	normal_fragment.priority = 0
	normal_fragment.text = "The room is calm."

	var tense_fragment := Fragment.new()
	tense_fragment.id = "tension_room"
	tense_fragment.priority = 100
	tense_fragment.conditions = ["variables.tension >= 3"]
	tense_fragment.text = "The room feels tense."

	store.add_all([normal_fragment, tense_fragment])

	var initial_fragment := store.get_active_fragment("tension_room", state)
	assert(initial_fragment == tense_fragment, "Expected high-priority fragment at variables.tension 3")
	print("PASS: variables.tension >= 3 selected high-priority fragment")

	ExpressionEvaluator.apply_effect("variables.phase = \"dream\"", state)
	assert(state.get_var("phase") == "dream", "Expected variables.phase assignment")
	print("PASS: variables.phase assignment works")

	var save_path := "user://test_variables_save.json"
	assert(ChronicaSerializer.save_state(state, save_path), "Expected variables save to succeed")
	var loaded := ChronicaSerializer.load_state(save_path)
	assert(loaded.get_var("tension") == 3, "Expected saved variables.tension to persist")
	assert(loaded.get_var("phase") == "dream", "Expected saved variables.phase to persist")
	print("PASS: save/load preserved variables")

	DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	store = null
	state = null
	loaded = null
	print("\nAll variables tests passed.")


func _run_instability_mirror_test() -> void:
	var state := ChronicaState.new()
	ExpressionEvaluator.apply_effect("instability += 1", state)
	assert(state.get_var("instability") == 1, "Expected legacy instability effect to write variables.instability")
	assert(state.instability == 1, "Expected legacy instability mirror to match variables.instability")
	print("PASS: legacy instability effect writes canonical variables.instability")

	state.set_var("instability", 3)
	var fragment := Fragment.new()
	fragment.id = "mirror_room"
	fragment.priority = 0
	fragment.conditions = ["instability >= 3"]
	fragment.text = "Threshold met."
	assert(fragment.is_valid(state), "Expected bare instability condition to read variables.instability")
	print("PASS: bare instability condition reads canonical variables.instability")

	state.reality_layer = 5
	ExpressionEvaluator.apply_effect("reality_layer += 1", state)
	assert(state.reality_layer == 6, "Expected reality_layer write unchanged by instability migration")
	print("PASS: reality_layer behavior unchanged by instability migration")

	state = null
	fragment = null
	print("\nAll instability mirror tests passed.")


func _run_fragment_loader_test() -> void:
	var fixtures_dir := "res://tests/fixtures/fragments"
	var alpha_path := "%s/alpha.tres" % fixtures_dir

	var alpha := FragmentLoader.load_fragment(alpha_path)
	assert(alpha != null, "Expected alpha fragment to load")
	assert(alpha.id == "fragment_alpha", "Expected alpha fragment ID")
	assert(alpha.priority == 20, "Expected alpha fragment priority")
	print("PASS: load_fragment loaded alpha.tres")

	var invalid := FragmentLoader.load_fragment("%s/invalid.tres" % fixtures_dir)
	assert(invalid == null, "Expected invalid.tres to be ignored")
	print("PASS: load_fragment ignored invalid resource")

	var fragments := FragmentLoader.load_directory(fixtures_dir)
	assert(fragments.size() == 2, "Expected 2 fragments, got %d" % fragments.size())
	assert(fragments[0].id == "fragment_beta", "Expected highest priority fragment first")
	assert(fragments[0].priority == 40, "Expected beta priority 40")
	assert(fragments[1].id == "fragment_alpha", "Expected alpha fragment second")
	assert(fragments[1].priority == 20, "Expected alpha priority 20")
	print("PASS: load_directory returned fragments sorted by priority")

	alpha = null
	var beta := FragmentLoader.load_fragment("%s/nested/beta.tres" % fixtures_dir)
	assert(beta != null and beta.id == "fragment_beta", "Expected nested beta fragment to load")
	beta = null
	fragments.clear()

	# 5. Bad directory returns empty without crashing
	var missing_dir := FragmentLoader.load_directory("res://does_not_exist_dir/")
	assert(missing_dir.is_empty(), "Expected missing directory to return empty array")
	print("PASS: load_directory on missing path returns empty array")

	# 6. Repeated loads duplicate entries unless caller clears store
	var duplicate_store := FragmentStore.new()
	duplicate_store.add_all(FragmentLoader.load_directory(fixtures_dir))
	duplicate_store.add_all(FragmentLoader.load_directory(fixtures_dir))
	assert(
		duplicate_store._fragments.size() == 4,
		"Expected doubled fragment count after loading same directory twice, got %d"
		% duplicate_store._fragments.size()
	)
	var duplicate_state := ChronicaState.new()
	duplicate_state.location = "fragment_beta"
	var duplicate_active := duplicate_store.get_active_fragment(
		duplicate_state.location,
		duplicate_state
	)
	assert(duplicate_active != null, "Expected store with duplicates to still resolve a fragment")
	assert(duplicate_active.id == "fragment_beta", "Expected highest-priority fragment after duplicate load")
	print("PASS: repeated load_directory into same store duplicates entries")

	# 7. Resource cache aliasing investigation
	var cache_path := alpha_path
	var cache_first := FragmentLoader.load_fragment(cache_path)
	var cache_second := FragmentLoader.load_fragment(cache_path)
	assert(cache_first != null and cache_second != null, "Expected cached path loads to succeed")
	assert(
		is_same(cache_first, cache_second),
		"Expected ResourceLoader cache to return same Fragment instance for repeated loads"
	)
	var original_text := cache_first.text
	cache_first.text = "mutated by cache aliasing test"
	var cache_third := FragmentLoader.load_fragment(cache_path)
	assert(
		cache_third.text == "mutated by cache aliasing test",
		"Expected cached Fragment mutation to be visible on subsequent loads"
	)
	cache_first.text = original_text
	print("PASS: FragmentLoader returns cached Fragment instances (mutation is shared)")

	duplicate_store = null
	duplicate_state = null
	cache_first = null
	cache_second = null
	cache_third = null
	print("\nAll fragment loader tests passed.")


func _run_fragment_ordering_test() -> void:
	var store := FragmentStore.new()
	var state := ChronicaState.new()
	state.location = "chapel_interior"

	var later_text := Fragment.new()
	later_text.id = "chapel_interior"
	later_text.priority = 10
	later_text.text = "Zulu variant."

	var earlier_text := Fragment.new()
	earlier_text.id = "chapel_interior"
	earlier_text.priority = 10
	earlier_text.text = "Alpha variant."

	store.add_all([later_text, earlier_text])
	var selected := store.get_active_fragment(state.location, state)
	assert(selected == earlier_text, "Expected text ascending tie-break for equal priority and id")
	print("PASS: FragmentStore resolves equal-priority/id ties by text")

	var tie_fragments := FragmentLoader.load_directory("res://tests/fixtures/fragment_ties")
	assert(tie_fragments.size() == 2, "Expected 2 tie-test fragments")
	assert(tie_fragments[0].id == "tie_aaa", "Expected tie_aaa first by id ascending")
	assert(tie_fragments[1].id == "tie_bbb", "Expected tie_bbb second by id ascending")

	var reloaded := FragmentLoader.load_directory("res://tests/fixtures/fragment_ties")
	assert(reloaded[0].id == tie_fragments[0].id, "Expected deterministic load_directory ordering")
	assert(reloaded[1].id == tie_fragments[1].id, "Expected deterministic load_directory ordering")
	print("PASS: load_directory returns equal-priority fragments in deterministic order")

	store = null
	state = null
	later_text = null
	earlier_text = null
	tie_fragments.clear()
	reloaded.clear()
	print("\nAll fragment ordering tests passed.")


func _run_session_test() -> void:
	var save_path := "user://session_test_save.json"
	var chapel_dir := "res://tests/fixtures/chapel"

	var session := ChronicaSession.new()
	add_child(session)

	var loaded_count := session.load_fragments(chapel_dir)
	assert(loaded_count == 2, "Expected 2 chapel fragments, got %d" % loaded_count)
	print("PASS: session loaded chapel fragments")

	var initial_fragment := session.start("chapel_interior")
	assert(initial_fragment != null, "Expected start to return a fragment")
	assert(
		initial_fragment.text == "The chapel stands intact, candles flickering softly.",
		"Expected normal chapel variant at start"
	)
	print("PASS: session start returned normal chapel variant")

	var choice := initial_fragment.choices[0]
	var result_fragment := session.choose(choice)
	assert(session.state.instability == 1, "Expected instability 1 after choice")
	assert(
		result_fragment.text == "The chapel is broken, stone cracked and candles extinguished.",
		"Expected broken chapel variant after choice"
	)
	print("PASS: session choose returned broken chapel variant")

	assert(session.save(save_path), "Expected session save to succeed")
	print("PASS: session saved state")

	var saved_instability := session.state.instability
	var saved_location := session.state.location

	session.queue_free()
	session = null

	var restored_session := ChronicaSession.new()
	add_child(restored_session)
	assert(restored_session.load(save_path), "Expected session load to succeed")
	assert(restored_session.state.location == saved_location, "Expected saved location to persist")
	assert(restored_session.state.instability == saved_instability, "Expected saved instability to persist")
	print("PASS: new session loaded saved state")

	var absolute_path := ProjectSettings.globalize_path(save_path)
	DirAccess.remove_absolute(absolute_path)

	restored_session.queue_free()
	print("\nAll session tests passed.")


func _run_instability_manager_test() -> void:
	var session := ChronicaSession.new()
	add_child(session)
	_add_instability_test_fragment(session)

	session.start("test_room")
	var choice := session.get_current_fragment().choices[0]
	for i in 3:
		session.choose(choice)

	assert(session.state.get_var("instability", 0) == 0, "Expected core session without modules to leave instability unchanged")
	print("PASS: core works without modules")

	session.queue_free()

	var managed_session := ChronicaSession.new()
	add_child(managed_session)
	_add_instability_test_fragment(managed_session)
	var incrementing_manager := InstabilityManager.new()
	incrementing_manager.auto_increment_per_turn = 1
	managed_session.add_module(incrementing_manager)

	managed_session.start("test_room")
	choice = managed_session.get_current_fragment().choices[0]

	for i in 3:
		managed_session.choose(choice)
	assert(managed_session.state.get_var("instability") == 3, "Expected variables.instability 3 after three turns")
	print("PASS: InstabilityManager incremented variables.instability to 3 with auto_increment_per_turn = 1")

	for i in 7:
		managed_session.choose(choice)
	assert(managed_session.state.get_var("instability") == 10, "Expected variables.instability 10 after ten turns")
	assert(managed_session.state.get_var("reality_phase") == 1, "Expected variables.reality_phase 1 at instability 10")
	print("PASS: InstabilityManager set variables.reality_phase at instability 10")

	managed_session.queue_free()

	var passive_session := ChronicaSession.new()
	add_child(passive_session)
	_add_instability_test_fragment(passive_session)
	passive_session.add_module(InstabilityManager.new())
	passive_session.start("test_room")
	choice = passive_session.get_current_fragment().choices[0]
	passive_session.choose(choice)
	assert(
		passive_session.state.get_var("instability", 0) == 0,
		"Expected default InstabilityManager not to increment instability"
	)
	print("PASS: InstabilityManager default does not increment instability per turn")

	passive_session.queue_free()
	print("\nAll instability manager tests passed.")


func _run_event_bus_test() -> void:
	var bus := ChronicaEventBus.new()
	var received: Array = []
	var callback := func(payload: Variant) -> void:
		received.append(payload)

	bus.subscribe("test_event", callback)
	bus.emit_event("test_event", "hello")
	assert(received.size() == 1, "Expected callback to run once")
	assert(received[0] == "hello", "Expected callback payload to match")
	print("PASS: subscribed callback received emitted payload")

	bus.unsubscribe("test_event", callback)
	bus.emit_event("test_event", "world")
	assert(received.size() == 1, "Expected unsubscribed callback not to run again")
	print("PASS: unsubscribed callback no longer executes")

	bus.emit_event("unknown_event", "ignored")
	print("PASS: emitting unknown event is a no-op")

	bus = null
	print("\nAll event bus tests passed.")


func _run_echo_manager_test() -> void:
	var save_path := "user://echo_test_save.json"
	var warden := _create_warden_echo()

	var session := ChronicaSession.new()
	add_child(session)

	var echo_manager := EchoManager.new()
	echo_manager.register_echo(warden)
	session.add_module(echo_manager)
	_add_instability_test_fragment(session)
	session.start("test_room")

	var choice := session.get_current_fragment().choices[0]

	session.state.set_var("instability", 2)
	session.choose(choice)
	assert(echo_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.DORMANT)
	print("PASS: warden echo DORMANT at variables.instability 2")

	session.state.set_var("instability", 3)
	session.choose(choice)
	assert(echo_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.ACTIVE)
	print("PASS: warden echo ACTIVE at variables.instability 3")

	session.state.set_var("instability", 5)
	session.choose(choice)
	assert(echo_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.MANIFESTED)
	print("PASS: warden echo MANIFESTED at variables.instability 5")

	session.state.set_var("spoke_to_warden", true)
	session.choose(choice)
	assert(echo_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.RESOLVED)
	print("PASS: warden echo RESOLVED after variables.spoke_to_warden")

	assert(session.save(save_path), "Expected echo session save to succeed")
	print("PASS: echo session saved")

	session.queue_free()

	var restored_session := ChronicaSession.new()
	add_child(restored_session)

	var restored_manager := EchoManager.new()
	restored_manager.register_echo(warden)
	restored_session.add_module(restored_manager)
	assert(restored_session.load(save_path), "Expected echo session load to succeed")
	assert(restored_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.RESOLVED)
	print("PASS: warden echo state persisted across save/load")

	DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	restored_session.queue_free()
	warden = null
	print("\nAll echo manager tests passed.")


func _run_echo_manager_extended_test() -> void:
	# 1. Resolved echoes stay resolved
	var sticky_warden := _create_warden_echo()
	sticky_warden.effects_on_activate = ["variables.warden_activate_runs += 1"]
	var sticky_session := ChronicaSession.new()
	add_child(sticky_session)
	var sticky_manager := EchoManager.new()
	sticky_manager.register_echo(sticky_warden)
	sticky_session.add_module(sticky_manager)
	_add_instability_test_fragment(sticky_session)
	sticky_session.start("test_room")
	var sticky_choice := sticky_session.get_current_fragment().choices[0]

	sticky_session.state.set_var("instability", 2)
	sticky_session.choose(sticky_choice)
	sticky_session.state.set_var("instability", 3)
	sticky_session.choose(sticky_choice)
	sticky_session.state.set_var("instability", 5)
	sticky_session.choose(sticky_choice)
	sticky_session.state.set_var("spoke_to_warden", true)
	sticky_session.choose(sticky_choice)
	assert(
		sticky_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.RESOLVED,
		"Expected warden RESOLVED before post-resolution turn"
	)
	assert(
		sticky_session.state.get_var("warden_activate_runs", 0) == 1,
		"Expected effects_on_activate to run once during lifecycle"
	)

	var post_resolve_events: Array = []
	sticky_session.event_bus.subscribe(
		"echo_activated",
		func(echo_id: Variant) -> void:
			post_resolve_events.append(echo_id)
	)
	sticky_session.event_bus.subscribe(
		"echo_manifested",
		func(echo_id: Variant) -> void:
			post_resolve_events.append(echo_id)
	)
	sticky_session.event_bus.subscribe(
		"echo_resolved",
		func(echo_id: Variant) -> void:
			post_resolve_events.append(echo_id)
	)
	sticky_session.state.set_var("instability", 10)
	sticky_session.choose(sticky_choice)
	assert(
		sticky_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.RESOLVED,
		"Expected resolved echo to stay RESOLVED when activation conditions still pass"
	)
	assert(post_resolve_events.is_empty(), "Expected no echo events after RESOLVED")
	assert(
		sticky_session.state.get_var("warden_activate_runs", 0) == 1,
		"Expected effects_on_activate not to re-run after RESOLVED"
	)
	print("PASS: resolved echo stays resolved and does not re-fire events or effects")

	sticky_session.queue_free()
	sticky_warden = null

	# 2. Failed turns do not advance echoes
	var fail_warden := _create_warden_echo()
	var fail_session := ChronicaSession.new()
	add_child(fail_session)
	var fail_manager := EchoManager.new()
	fail_manager.register_echo(fail_warden)
	fail_session.add_module(fail_manager)
	_add_instability_test_fragment(fail_session)
	fail_session.start("test_room")
	fail_session.state.set_var("instability", 3)
	var echoes_before: Variant = fail_session.state.get_var("echoes", {})
	var invalid_result := fail_session.choose(
		Choice.new("Leave through the wrong door", "goto:missing_room")
	)
	assert(invalid_result == null, "Expected invalid goto to return null")
	assert(
		fail_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.DORMANT,
		"Expected echo to remain DORMANT on failed turn"
	)
	assert(
		fail_session.state.get_var("echoes", {}) == echoes_before,
		"Expected variables.echoes unchanged on failed turn"
	)
	print("PASS: failed turn does not advance echo lifecycle")

	fail_session.queue_free()
	fail_warden = null

	# 3. Load-before-register preserves lifecycle from save
	var load_first_save := "user://echo_load_before_register.json"
	var preload_state := ChronicaState.new()
	preload_state.location = "test_room"
	preload_state.set_var("echoes", {"warden": EchoManager.EchoLifecycle.RESOLVED})
	assert(
		ChronicaSerializer.save_state(preload_state, load_first_save),
		"Expected preload save to succeed"
	)

	var load_first_session := ChronicaSession.new()
	add_child(load_first_session)
	var load_first_manager := EchoManager.new()
	load_first_session.add_module(load_first_manager)
	assert(load_first_session.load(load_first_save), "Expected load-before-register save to load")
	load_first_manager.register_echo(_create_warden_echo())
	assert(
		load_first_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.RESOLVED,
		"Expected register_echo after load to preserve resolved lifecycle"
	)
	print("PASS: load-before-register preserves echo lifecycle from save")

	DirAccess.remove_absolute(ProjectSettings.globalize_path(load_first_save))
	load_first_session.queue_free()
	preload_state = null

	# 4. Orphan echo ids do not crash and persist across turns
	var orphan_save := "user://echo_orphan_save.json"
	var orphan_state := ChronicaState.new()
	orphan_state.location = "test_room"
	orphan_state.set_var(
		"echoes",
		{"ghost_echo": EchoManager.EchoLifecycle.MANIFESTED, "warden": EchoManager.EchoLifecycle.DORMANT}
	)
	assert(ChronicaSerializer.save_state(orphan_state, orphan_save), "Expected orphan save to succeed")

	var orphan_session := ChronicaSession.new()
	add_child(orphan_session)
	var orphan_manager := EchoManager.new()
	orphan_session.add_module(orphan_manager)
	_add_instability_test_fragment(orphan_session)
	assert(orphan_session.load(orphan_save), "Expected orphan echo save to load")
	orphan_manager.register_echo(_create_warden_echo())
	var orphan_choice := orphan_session.get_current_fragment().choices[0]
	orphan_session.state.set_var("instability", 3)
	orphan_session.choose(orphan_choice)
	assert(
		orphan_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.ACTIVE,
		"Expected registered warden echo to evaluate normally beside orphan"
	)
	var persisted_echoes: Variant = orphan_session.state.get_var("echoes", {})
	assert(persisted_echoes is Dictionary, "Expected variables.echoes dictionary after turn")
	assert(
		int((persisted_echoes as Dictionary).get("ghost_echo", -1))
		== EchoManager.EchoLifecycle.MANIFESTED,
		"Expected orphan ghost_echo entry to persist in variables.echoes"
	)
	print("PASS: orphan echo id persists and does not affect registered echo evaluation")

	DirAccess.remove_absolute(ProjectSettings.globalize_path(orphan_save))
	orphan_session.queue_free()
	orphan_state = null
	print("\nAll echo manager extended tests passed.")


func _run_module_order_test() -> void:
	# InstabilityManager must run before EchoManager on the same turn so echo
	# activation sees this turn's instability increment (2 -> 3). Registration
	# order below is reversed; class priorities determine execution order.
	var warden := _create_warden_echo()
	var session := ChronicaSession.new()
	add_child(session)

	var echo_manager := EchoManager.new()
	echo_manager.register_echo(warden)
	session.add_module(echo_manager)

	var incrementing_manager := InstabilityManager.new()
	incrementing_manager.auto_increment_per_turn = 1
	session.add_module(incrementing_manager)
	_add_instability_test_fragment(session)
	session.start("test_room")

	session.state.set_var("instability", 2)
	var choice := session.get_current_fragment().choices[0]
	session.choose(choice)

	assert(
		session.state.get_var("instability") == 3,
		"Expected InstabilityManager to increment instability to 3"
	)
	assert(
		echo_manager.get_echo_state("warden") == EchoManager.EchoLifecycle.ACTIVE,
		"Expected warden echo ACTIVE same turn when InstabilityManager runs before EchoManager"
	)
	print("PASS: module priority runs InstabilityManager before EchoManager regardless of registration order")

	session.queue_free()
	warden = null
	print("\nAll module order tests passed.")


func _run_atomic_turn_regression_test() -> void:
	# 1. Invalid goto does not mutate state
	var store := FragmentStore.new()
	var chapel_fragment := _add_chapel_turn_test_fragment(store)

	var state := ChronicaState.new()
	state.location = "chapel_interior"
	state.memory = {"visited_chapel": true}
	state.set_var("tension", 4)
	state.set_var("phase", "calm")

	var turn_resolver := TurnResolver.new()
	add_child(turn_resolver)

	var invalid_choice := Choice.new("Leave through the wrong door", "goto:missing_room")
	var invalid_result := turn_resolver.resolve(invalid_choice, state, store)

	assert(invalid_result == null, "Expected invalid goto to return null")
	assert(state.location == "chapel_interior", "Expected location to remain chapel_interior")
	assert(state.memory == {"visited_chapel": true}, "Expected memory to remain unchanged")
	assert(state.get_var("tension") == 4, "Expected variables.tension to remain unchanged")
	assert(state.get_var("phase") == "calm", "Expected variables.phase to remain unchanged")
	print("PASS: invalid goto does not mutate state")

	# 2. No turn_resolved signal on failed resolution
	var callback_count: Array = [0]
	turn_resolver.turn_resolved.connect(
		func(_previous_state: ChronicaState, _current_state: ChronicaState, _choice: Choice, _fragment: Fragment) -> void:
			callback_count[0] += 1
	)

	turn_resolver.resolve(invalid_choice, state, store)
	assert(callback_count[0] == 0, "Expected turn_resolved not to fire on failed resolution")
	print("PASS: turn_resolved not emitted on failed resolution")

	# 3. Committed state identity on valid resolution
	var emitted_state_ref: Array = [null]
	turn_resolver.turn_resolved.connect(
		func(_previous_state: ChronicaState, current_state: ChronicaState, _choice: Choice, _fragment: Fragment) -> void:
			emitted_state_ref[0] = current_state
	)

	var valid_choice := chapel_fragment.choices[0]
	var valid_result := turn_resolver.resolve(valid_choice, state, store)

	assert(valid_result != null, "Expected valid choice to return a fragment")
	assert(emitted_state_ref[0] != null, "Expected turn_resolved to emit a state")
	assert(is_same(emitted_state_ref[0], state), "Expected turn_resolved current_state to be the committed state object")
	print("PASS: turn_resolved emits committed state identity")

	chapel_fragment.choices = []
	turn_resolver.queue_free()
	store = null
	state = null
	print("\nAll atomic turn regression tests passed.")


func _run_fragment_validator_test() -> void:
	var missing_id := Fragment.new()
	missing_id.text = "Missing id fragment."
	var missing_id_result := FragmentValidator.validate_fragments([missing_id])
	assert(_validator_has_issue(missing_id_result, "error", "MISSING_FRAGMENT_ID"))
	print("PASS: validator reports missing fragment id")

	var invalid_condition := _validator_fragment("room_a")
	invalid_condition.conditions = ["not a valid condition"]
	var invalid_condition_result := FragmentValidator.validate_fragments([invalid_condition])
	assert(_validator_has_issue(invalid_condition_result, "error", "INVALID_CONDITION"))
	print("PASS: validator reports invalid condition syntax")

	var invalid_effect := _validator_fragment("room_a")
	invalid_effect.effects = ["definitely invalid effect"]
	var invalid_effect_result := FragmentValidator.validate_fragments([invalid_effect])
	assert(_validator_has_issue(invalid_effect_result, "error", "INVALID_EFFECT"))
	print("PASS: validator reports invalid effect syntax")

	var invalid_action := _validator_fragment("room_a")
	invalid_action.choices = [Choice.new("Broken", "definitely invalid action")]
	var invalid_action_result := FragmentValidator.validate_fragments([invalid_action])
	assert(_validator_has_issue(invalid_action_result, "error", "INVALID_ACTION"))
	print("PASS: validator reports invalid action syntax")

	var goto_source := _validator_fragment("room_a")
	goto_source.choices = [Choice.new("Go missing", "goto:missing_room")]
	var invalid_goto_result := FragmentValidator.validate_fragments([goto_source])
	assert(_validator_has_issue(invalid_goto_result, "error", "INVALID_GOTO_TARGET"))
	print("PASS: validator reports invalid goto target")

	var empty_label := _validator_fragment("room_a")
	empty_label.choices = [Choice.new("", "goto:room_a")]
	var empty_label_result := FragmentValidator.validate_fragments([empty_label])
	assert(_validator_has_issue(empty_label_result, "error", "EMPTY_CHOICE_LABEL"))
	print("PASS: validator reports empty choice label")

	var tie_a := _validator_fragment("room_a")
	tie_a.priority = 5
	tie_a.text = "Alpha"
	var tie_b := _validator_fragment("room_a")
	tie_b.priority = 5
	tie_b.text = "Beta"
	var same_priority_result := FragmentValidator.validate_fragments([tie_a, tie_b])
	assert(_validator_has_issue(same_priority_result, "warning", "SAME_ID_PRIORITY"))
	print("PASS: validator warns on same id and priority")

	var duplicate_a := _validator_fragment("room_a")
	duplicate_a.priority = 2
	duplicate_a.conditions = ["variables.tension >= 1"]
	var duplicate_b := _validator_fragment("room_a")
	duplicate_b.priority = 2
	duplicate_b.conditions = ["variables.tension >= 1"]
	var duplicate_variant_result := FragmentValidator.validate_fragments([duplicate_a, duplicate_b])
	assert(_validator_has_issue(duplicate_variant_result, "warning", "DUPLICATE_VARIANT"))
	print("PASS: validator warns on duplicate id, priority, and conditions")

	var conditional_only := _validator_fragment("room_a")
	conditional_only.conditions = ["variables.tension >= 1"]
	var missing_fallback_result := FragmentValidator.validate_fragments([conditional_only])
	assert(_validator_has_issue(missing_fallback_result, "warning", "MISSING_FALLBACK"))
	print("PASS: validator warns on missing unconditional fallback")

	var legacy := _validator_fragment("room_a")
	legacy.conditions = ["instability >= 3"]
	var legacy_result := FragmentValidator.validate_fragments([legacy])
	assert(not legacy_result.has_errors(), "Expected legacy condition syntax to remain valid")
	assert(_validator_has_issue(legacy_result, "warning", "LEGACY_SYNTAX"))
	assert(_validator_issue_message(legacy_result, "LEGACY_SYNTAX") == FragmentValidator.LEGACY_SYNTAX_MESSAGE)
	print("PASS: validator warns on legacy condition without error")

	var legacy_effect := _validator_fragment("room_a")
	legacy_effect.effects = ["reality_layer += 1"]
	var legacy_effect_result := FragmentValidator.validate_fragments([legacy_effect])
	assert(not legacy_effect_result.has_errors(), "Expected legacy effect syntax to remain valid")
	assert(_validator_has_issue(legacy_effect_result, "warning", "LEGACY_SYNTAX"))
	print("PASS: validator warns on legacy effect without error")

	var modern_paths := _validator_fragment("room_a")
	modern_paths.conditions = ["variables.tension >= 1", "memory.visited == true"]
	modern_paths.effects = ["variables.tension += 1"]
	modern_paths.choices = [Choice.new("Go", "goto:room_a")]
	var modern_paths_result := FragmentValidator.validate_fragments([modern_paths])
	assert(not _validator_has_issue(modern_paths_result, "warning", "LEGACY_SYNTAX"))
	print("PASS: validator does not warn on variables.* or memory.* paths")

	var unused_read := _validator_fragment("room_a")
	unused_read.conditions = ["variables.ghost >= 1"]
	var unused_read_result := FragmentValidator.validate_fragments([unused_read])
	assert(_validator_has_issue(unused_read_result, "warning", "UNUSED_VARIABLE_READ"))
	print("PASS: validator warns on unused variable read")

	var valid := _validator_fragment("room_a")
	valid.effects = ["variables.tension += 1"]
	valid.choices = [Choice.new("Stay", "variables.tension += 1")]
	valid.conditions = ["variables.tension >= 0"]
	var valid_result := FragmentValidator.validate_fragments([valid])
	assert(not valid_result.has_errors())
	print("PASS: validator accepts valid fragment content")

	var sorted := ValidationResult.new()
	sorted.add_warning("Z_WARNING", "Later warning", "room_z")
	sorted.add_error("B_ERROR", "Beta error", "room_b")
	sorted.add_error("A_ERROR", "Alpha error", "room_a")
	sorted.sort_issues()
	assert(sorted.issues[0].severity == "error")
	assert(sorted.issues[0].code == "A_ERROR")
	assert(sorted.issues[1].code == "B_ERROR")
	assert(sorted.issues[2].severity == "warning")
	print("PASS: validator sorts issues deterministically")

	missing_id = null
	print("\nAll fragment validator tests passed.")


func _validator_fragment(id: String) -> Fragment:
	var fragment := Fragment.new()
	fragment.id = id
	fragment.text = "Validator test fragment."
	fragment.choices = []
	return fragment


func _validator_has_issue(result: ValidationResult, severity: String, code: String) -> bool:
	for issue in result.issues:
		if issue.severity == severity and issue.code == code:
			return true
	return false


func _validator_issue_message(result: ValidationResult, code: String) -> String:
	for issue in result.issues:
		if issue.code == code:
			return issue.message
	return ""


func _add_chapel_turn_test_fragment(store: FragmentStore) -> Fragment:
	var chapel_fragment := Fragment.new()
	chapel_fragment.id = "chapel_interior"
	chapel_fragment.priority = 0
	chapel_fragment.text = "The chapel stands intact."
	chapel_fragment.choices = [
		Choice.new("Disturb the silence", "instability += 1"),
	]
	store.add(chapel_fragment)
	return chapel_fragment


func _create_warden_echo() -> EchoDefinition:
	var warden := EchoDefinition.new()
	warden.id = "warden"
	warden.activation_conditions = ["variables.instability >= 3"]
	warden.manifestation_conditions = ["variables.instability >= 5"]
	warden.resolution_conditions = ["variables.spoke_to_warden == true"]
	return warden


func _add_instability_test_fragment(session: ChronicaSession) -> void:
	var fragment := Fragment.new()
	fragment.id = "test_room"
	fragment.priority = 0
	fragment.text = "A quiet test room."
	fragment.choices = [Choice.new("Wait", "")]
	session.store.add(fragment)
