class_name ExpressionEvaluator
extends RefCounted

static var _condition_pattern: RegEx
static var _increment_pattern: RegEx
static var _assignment_pattern: RegEx


static func _condition_regex() -> RegEx:
	if _condition_pattern == null:
		_condition_pattern = RegEx.create_from_string(
			"^\\s*(\\w+(?:\\.\\w+)?)\\s*(>=|<=|==|!=|>|<)\\s*(.+)\\s*$"
		)
	return _condition_pattern


static func _increment_regex() -> RegEx:
	if _increment_pattern == null:
		_increment_pattern = RegEx.create_from_string(
			"^\\s*(\\w+(?:\\.\\w+)?)\\s*\\+=\\s*(-?\\d+)\\s*$"
		)
	return _increment_pattern


static func _assignment_regex() -> RegEx:
	if _assignment_pattern == null:
		_assignment_pattern = RegEx.create_from_string(
			"^\\s*(\\w+(?:\\.\\w+)?)\\s*=\\s*(.+)\\s*$"
		)
	return _assignment_pattern


static func evaluate_condition(expression: String, state: ChronicaState) -> bool:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return true

	var match_result := _condition_regex().search(trimmed)
	if match_result == null:
		push_error("Unsupported condition expression: %s" % expression)
		return false

	var left_path := match_result.get_string(1)
	var operator := match_result.get_string(2)
	var right_value := _parse_value(match_result.get_string(3).strip_edges())
	var left_value := _resolve_path(left_path, state)

	return _compare(left_value, operator, right_value)


static func is_valid_condition(expression: String) -> bool:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return true

	return _condition_regex().search(trimmed) != null


static func is_valid_effect(expression: String) -> bool:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return true

	if _increment_regex().search(trimmed) != null:
		return true

	return _assignment_regex().search(trimmed) != null


static func get_condition_left_path(expression: String) -> String:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return ""

	var match_result := _condition_regex().search(trimmed)
	if match_result == null:
		return ""

	return match_result.get_string(1)


static func get_effect_write_path(expression: String) -> String:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return ""

	var increment_match := _increment_regex().search(trimmed)
	if increment_match != null:
		return increment_match.get_string(1)

	var assignment_match := _assignment_regex().search(trimmed)
	if assignment_match != null:
		return assignment_match.get_string(1)

	return ""


static func is_legacy_path(path: String) -> bool:
	return path == "instability" or path == "reality_layer"


static func apply_effect(expression: String, state: ChronicaState) -> void:
	var trimmed := expression.strip_edges()
	if trimmed.is_empty():
		return

	var increment_match := _increment_regex().search(trimmed)
	if increment_match != null:
		var path := increment_match.get_string(1)
		var amount := int(increment_match.get_string(2))
		_apply_increment(path, amount, state)
		return

	var assignment_match := _assignment_regex().search(trimmed)
	if assignment_match != null:
		var path := assignment_match.get_string(1)
		var value := _parse_value(assignment_match.get_string(2).strip_edges())
		_apply_assignment(path, value, state)
		return

	push_error("Unsupported effect expression: %s" % expression)


static func _resolve_path(path: String, state: ChronicaState) -> Variant:
	if path.begins_with("memory."):
		var key := path.substr(7)
		return state.memory.get(key, false)

	if path.begins_with("variables."):
		var key := path.substr(10)
		return state.get_var(key, 0)

	match path:
		"instability":
			return int(state.get_var("instability", 0))
		"reality_layer":
			return state.reality_layer
		"location":
			return state.location
		_:
			push_error("Unknown state path: %s" % path)
			return null


static func _apply_increment(path: String, amount: int, state: ChronicaState) -> void:
	if path.begins_with("memory."):
		var key := path.substr(7)
		var current := int(state.memory.get(key, 0))
		state.memory[key] = current + amount
		return

	if path.begins_with("variables."):
		var key := path.substr(10)
		state.add_var(key, amount)
		return

	match path:
		"instability":
			state.add_var("instability", amount)
		"reality_layer":
			state.reality_layer += amount
		_:
			push_error("Cannot increment unknown path: %s" % path)


static func _apply_assignment(path: String, value: Variant, state: ChronicaState) -> void:
	if path.begins_with("memory."):
		var key := path.substr(7)
		state.memory[key] = value
		return

	if path.begins_with("variables."):
		var key := path.substr(10)
		state.set_var(key, value)
		return

	match path:
		"instability":
			state.set_var("instability", int(value))
		"reality_layer":
			state.reality_layer = int(value)
		"location":
			state.location = str(value)
		_:
			push_error("Cannot assign unknown path: %s" % path)


static func _compare(left: Variant, operator: String, right: Variant) -> bool:
	match operator:
		">=":
			return left >= right
		"<=":
			return left <= right
		"==":
			return left == right
		"!=":
			return left != right
		">":
			return left > right
		"<":
			return left < right
		_:
			return false


static func _parse_value(raw: String) -> Variant:
	if raw == "true":
		return true
	if raw == "false":
		return false
	if raw.is_valid_int():
		return int(raw)
	if raw.is_valid_float():
		return float(raw)
	if (
		(raw.begins_with("\"") and raw.ends_with("\""))
		or (raw.begins_with("'") and raw.ends_with("'"))
	):
		return raw.substr(1, raw.length() - 2)
	return raw
