class_name ChronicaEventBus
extends RefCounted

var _subscribers: Dictionary = {}


func subscribe(event_name: String, callable: Callable) -> void:
	if not _subscribers.has(event_name):
		_subscribers[event_name] = []

	var handlers: Array = _subscribers[event_name]
	if not handlers.has(callable):
		handlers.append(callable)


func unsubscribe(event_name: String, callable: Callable) -> void:
	if not _subscribers.has(event_name):
		return

	var handlers: Array = _subscribers[event_name]
	handlers.erase(callable)

	if handlers.is_empty():
		_subscribers.erase(event_name)


func emit_event(event_name: String, payload: Variant = null) -> void:
	if not _subscribers.has(event_name):
		return

	var handlers: Array = (_subscribers[event_name] as Array).duplicate()
	var current_handlers: Array = _subscribers[event_name]

	for handler in handlers:
		if not handler is Callable or not handler.is_valid():
			continue
		if not current_handlers.has(handler):
			continue
		handler.call(payload)
