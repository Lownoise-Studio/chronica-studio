class_name ChronicaModule
extends RefCounted

var priority: int = 0


func initialize(session: ChronicaSession) -> void:
	pass


func on_turn_resolved(
	previous_state: ChronicaState,
	current_state: ChronicaState,
	choice: Choice,
	fragment: Fragment
) -> void:
	pass


func on_session_loaded(state: ChronicaState) -> void:
	pass
