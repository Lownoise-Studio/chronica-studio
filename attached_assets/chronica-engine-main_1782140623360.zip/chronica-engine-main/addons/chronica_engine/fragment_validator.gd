class_name FragmentValidator
extends RefCounted

const LEGACY_SYNTAX_MESSAGE := "Supported legacy path. Prefer variables.* for new content."


static func validate_fragments(fragments: Array[Fragment]) -> ValidationResult:
	var result := ValidationResult.new()
	var known_ids := _collect_known_ids(fragments)
	var written_variables := _collect_written_variables(fragments)
	var warned_unused_reads: Dictionary = {}

	for fragment in fragments:
		var fragment_id := fragment.id

		if fragment_id.is_empty():
			result.add_error("MISSING_FRAGMENT_ID", "Fragment is missing id", fragment_id)

		for condition in fragment.conditions:
			if not ExpressionEvaluator.is_valid_condition(condition):
				result.add_error(
					"INVALID_CONDITION",
					"Invalid condition expression: %s" % condition,
					fragment_id
				)
				continue

			var read_path := ExpressionEvaluator.get_condition_left_path(condition)
			if ExpressionEvaluator.is_legacy_path(read_path):
				_add_legacy_warning(result, fragment_id)
			elif read_path.begins_with("variables."):
				var variable_name := read_path.substr(10)
				var warning_key := "%s|%s" % [fragment_id, variable_name]
				if not written_variables.has(variable_name) and not warned_unused_reads.has(warning_key):
					warned_unused_reads[warning_key] = true
					result.add_warning(
						"UNUSED_VARIABLE_READ",
						"Condition references variables.%s but no loaded effect or action writes it"
						% variable_name,
						fragment_id
					)

		for effect in fragment.effects:
			if not ExpressionEvaluator.is_valid_effect(effect):
				result.add_error(
					"INVALID_EFFECT",
					"Invalid effect expression: %s" % effect,
					fragment_id
				)
				continue

			var write_path := ExpressionEvaluator.get_effect_write_path(effect)
			if ExpressionEvaluator.is_legacy_path(write_path):
				_add_legacy_warning(result, fragment_id)

		for choice in fragment.choices:
			if choice.label.strip_edges().is_empty():
				result.add_error(
					"EMPTY_CHOICE_LABEL",
					"Choice is missing label",
					fragment_id
				)

			var action := choice.action.strip_edges()
			if not _is_valid_action(action):
				result.add_error(
					"INVALID_ACTION",
					"Invalid choice action: %s" % choice.action,
					fragment_id
				)
				continue

			if action.begins_with("goto:"):
				var target := action.substr(5)
				if not known_ids.has(target):
					result.add_error(
						"INVALID_GOTO_TARGET",
						"Choice action references unknown location: %s" % target,
						fragment_id
					)
				continue

			var action_write_path := ExpressionEvaluator.get_effect_write_path(action)
			if ExpressionEvaluator.is_legacy_path(action_write_path):
				_add_legacy_warning(result, fragment_id)

	_check_same_id_priority(fragments, result)
	_check_duplicate_variants(fragments, result)
	_check_missing_fallbacks(fragments, result)
	result.sort_issues()
	return result


static func _is_valid_action(action: String) -> bool:
	if action.is_empty():
		return true

	if action.begins_with("goto:"):
		return not action.substr(5).strip_edges().is_empty()

	return ExpressionEvaluator.is_valid_effect(action)


static func _add_legacy_warning(result: ValidationResult, fragment_id: String) -> void:
	result.add_warning("LEGACY_SYNTAX", LEGACY_SYNTAX_MESSAGE, fragment_id)


static func _collect_known_ids(fragments: Array[Fragment]) -> Dictionary:
	var known_ids := {}
	for fragment in fragments:
		if not fragment.id.is_empty():
			known_ids[fragment.id] = true
	return known_ids


static func _collect_written_variables(fragments: Array[Fragment]) -> Dictionary:
	var written_variables := {}

	for fragment in fragments:
		for effect in fragment.effects:
			_record_variable_write(written_variables, ExpressionEvaluator.get_effect_write_path(effect))

		for choice in fragment.choices:
			var action := choice.action.strip_edges()
			if action.is_empty() or action.begins_with("goto:"):
				continue
			_record_variable_write(written_variables, ExpressionEvaluator.get_effect_write_path(action))

	return written_variables


static func _record_variable_write(written_variables: Dictionary, path: String) -> void:
	if path.begins_with("variables."):
		written_variables[path.substr(10)] = true


static func _check_same_id_priority(fragments: Array[Fragment], result: ValidationResult) -> void:
	var groups: Dictionary = {}

	for fragment in fragments:
		if fragment.id.is_empty():
			continue
		var key := "%s|%d" % [fragment.id, fragment.priority]
		if not groups.has(key):
			groups[key] = []
		(groups[key] as Array).append(fragment)

	for key in groups:
		var group: Array = groups[key]
		if group.size() <= 1:
			continue

		for fragment in group:
			result.add_warning(
				"SAME_ID_PRIORITY",
				"Multiple fragments share id '%s' and priority %d" % [fragment.id, fragment.priority],
				fragment.id
			)


static func _check_duplicate_variants(fragments: Array[Fragment], result: ValidationResult) -> void:
	var seen: Dictionary = {}

	for fragment in fragments:
		if fragment.id.is_empty():
			continue

		var variant_key := "%s|%d|%s" % [fragment.id, fragment.priority, "|".join(fragment.conditions)]
		if seen.has(variant_key):
			result.add_warning(
				"DUPLICATE_VARIANT",
				"Duplicate fragment variant for id '%s' with identical priority and conditions"
				% fragment.id,
				fragment.id
			)
			continue

		seen[variant_key] = true


static func _check_missing_fallbacks(fragments: Array[Fragment], result: ValidationResult) -> void:
	var ids_with_fallback: Dictionary = {}
	var ids_seen: Dictionary = {}

	for fragment in fragments:
		if fragment.id.is_empty():
			continue

		ids_seen[fragment.id] = true
		if fragment.conditions.is_empty():
			ids_with_fallback[fragment.id] = true

	for fragment_id in ids_seen:
		if ids_with_fallback.has(fragment_id):
			continue

		result.add_warning(
			"MISSING_FALLBACK",
			"Fragment id '%s' has no unconditional fallback variant" % fragment_id,
			fragment_id
		)
