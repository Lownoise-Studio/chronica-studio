class_name EchoDefinition
extends Resource

@export var id: String = ""
@export var activation_conditions: Array[String] = []
@export var manifestation_conditions: Array[String] = []
@export var resolution_conditions: Array[String] = []
@export var effects_on_activate: Array[String] = []
@export var effects_on_manifest: Array[String] = []
@export var effects_on_resolve: Array[String] = []
