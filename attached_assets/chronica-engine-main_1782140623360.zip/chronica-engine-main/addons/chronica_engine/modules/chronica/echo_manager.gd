class_name EchoManager
extends ChronicaModule

enum EchoLifecycle {
	DORMANT = 0,
	ACTIVE = 1,
	MANIFESTED = 2,
	RESOLVED = 3,
}

var echoes: Dictionary = {}
var echo_states: Dictionary = {}

var _session: ChronicaSession


func _init() -> void:
	priority = 10


func initialize(session: ChronicaSession) -> void:
	_session = session
	if _session.state != null:
		_load_echo_states_from_state()


func register_echo(echo: EchoDefinition) -> void:
	echoes[echo.id] = echo
	if not echo_states.has(echo.id):
		echo_states[echo.id] = EchoLifecycle.DORMANT


func get_echo_state(id: String) -> int:
	return int(echo_states.get(id, EchoLifecycle.DORMANT))


func on_turn_resolved(
	_previous_state: ChronicaState,
	_current_state: ChronicaState,
	_choice: Choice,
	fragment: Fragment
) -> void:
	if fragment == null or _session.state == null:
		return

	_evaluate_all_echoes()


func on_session_loaded(_state: ChronicaState) -> void:
	_load_echo_states_from_state()


func _evaluate_all_echoes() -> void:
	for echo_id in echoes:
		_evaluate_echo(echoes[echo_id] as EchoDefinition)


func _evaluate_echo(echo: EchoDefinition) -> void:
	var current_state := get_echo_state(echo.id)
	var narrative_state := _session.state

	match current_state:
		EchoLifecycle.DORMANT:
			if _conditions_pass(echo.activation_conditions, narrative_state):
				_set_echo_state(echo.id, EchoLifecycle.ACTIVE)
				_apply_effects(echo.effects_on_activate, narrative_state)
				_session.event_bus.emit_event("echo_activated", echo.id)
		EchoLifecycle.ACTIVE:
			if _conditions_pass(echo.manifestation_conditions, narrative_state):
				_set_echo_state(echo.id, EchoLifecycle.MANIFESTED)
				_apply_effects(echo.effects_on_manifest, narrative_state)
				_session.event_bus.emit_event("echo_manifested", echo.id)
		EchoLifecycle.MANIFESTED:
			if _conditions_pass(echo.resolution_conditions, narrative_state):
				_set_echo_state(echo.id, EchoLifecycle.RESOLVED)
				_apply_effects(echo.effects_on_resolve, narrative_state)
				_session.event_bus.emit_event("echo_resolved", echo.id)


func _conditions_pass(conditions: Array[String], narrative_state: ChronicaState) -> bool:
	for condition in conditions:
		if not ExpressionEvaluator.evaluate_condition(condition, narrative_state):
			return false
	return true


func _apply_effects(effects: Array[String], narrative_state: ChronicaState) -> void:
	for effect in effects:
		ExpressionEvaluator.apply_effect(effect, narrative_state)


func _set_echo_state(echo_id: String, lifecycle_state: int) -> void:
	echo_states[echo_id] = lifecycle_state
	_persist_echo_states()


func _persist_echo_states() -> void:
	if _session.state == null:
		return

	var persisted := {}
	for echo_id in echo_states:
		persisted[echo_id] = echo_states[echo_id]

	_session.state.set_var("echoes", persisted)


func _load_echo_states_from_state() -> void:
	if _session.state == null:
		return

	var persisted: Variant = _session.state.get_var("echoes", {})
	if not persisted is Dictionary:
		return

	for echo_id in persisted:
		echo_states[echo_id] = int(persisted[echo_id])
