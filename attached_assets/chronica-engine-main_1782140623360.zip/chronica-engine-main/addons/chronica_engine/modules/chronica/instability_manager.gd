class_name InstabilityManager
extends ChronicaModule

var auto_increment_per_turn: int = 0

var _session: ChronicaSession


func _init() -> void:
	priority = 0


func initialize(session: ChronicaSession) -> void:
	_session = session


func on_turn_resolved(
	_previous_state: ChronicaState,
	_current_state: ChronicaState,
	_choice: Choice,
	fragment: Fragment
) -> void:
	if fragment == null or _session.state == null:
		return

	if auto_increment_per_turn != 0:
		_session.state.add_var("instability", auto_increment_per_turn)

	if int(_session.state.get_var("instability", 0)) >= 10:
		_session.state.set_var("reality_phase", 1)
