class_name TurnResolver
extends Node

signal turn_resolved(
	previous_state: ChronicaState,
	current_state: ChronicaState,
	choice: Choice,
	fragment: Fragment
)


func resolve(choice: Choice, state: ChronicaState, store: FragmentStore) -> Fragment:
	var previous_state := state.duplicate_state()
	var current_state := state.duplicate_state()

	ActionResolver.resolve(choice.action, current_state)

	var fragment := store.get_active_fragment(current_state.location, current_state)
	if fragment == null:
		return null

	fragment.apply_effects(current_state)
	_commit_state(state, current_state)
	turn_resolved.emit(previous_state, state, choice, fragment)
	return fragment


func _commit_state(state: ChronicaState, current_state: ChronicaState) -> void:
	state.location = current_state.location
	state.reality_layer = current_state.reality_layer
	state.memory = current_state.memory.duplicate(true)
	state.variables = current_state.variables.duplicate(true)
	state.instability = int(state.get_var("instability", 0))
