class_name Fragment
extends Resource

var id: String = ""
var priority: int = 0
var conditions: Array[String] = []
var effects: Array[String] = []
var text: String = ""
var choices: Array[Choice] = []


func is_valid(state: ChronicaState) -> bool:
	for condition in conditions:
		if not ExpressionEvaluator.evaluate_condition(condition, state):
			return false
	return true


func apply_effects(state: ChronicaState) -> void:
	for effect in effects:
		ExpressionEvaluator.apply_effect(effect, state)
