class_name FragmentLoader
extends RefCounted


static func load_fragment(path: String) -> Fragment:
	if path.is_empty() or not path.ends_with(".tres"):
		return null

	if not ResourceLoader.exists(path):
		return null

	# ResourceLoader.load() uses the default resource cache. Fragments are treated as
	# immutable at runtime; engine code reads fragment fields but never mutates them.
	var resource: Resource = ResourceLoader.load(path)
	if resource is Fragment:
		return resource

	return null


static func load_directory(path: String) -> Array[Fragment]:
	var fragments: Array[Fragment] = []
	_collect_fragments(path, fragments)
	_sort_fragments(fragments)
	return fragments


static func _collect_fragments(path: String, fragments: Array[Fragment]) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return

	for subdirectory in dir.get_directories():
		_collect_fragments(path.path_join(subdirectory), fragments)

	for file_name in dir.get_files():
		if not file_name.ends_with(".tres"):
			continue

		var fragment := load_fragment(path.path_join(file_name))
		if fragment != null:
			fragments.append(fragment)


static func _sort_fragments(fragments: Array[Fragment]) -> void:
	fragments.sort_custom(FragmentSorter.compare)
