class_name ChronicaState
extends Resource

var location: String = ""
var instability: int = 0
var reality_layer: int = 0
var memory: Dictionary = {}
var variables: Dictionary = {}


func get_var(name: String, default_value: Variant = null) -> Variant:
	return variables.get(name, default_value)


func set_var(name: String, value: Variant) -> void:
	variables[name] = value
	if name == "instability":
		sync_instability_mirror()


func add_var(name: String, amount: Variant) -> void:
	var current: Variant = variables.get(name, 0)
	if current is int or current is float:
		variables[name] = int(current) + int(amount)
	else:
		variables[name] = int(amount)
	if name == "instability":
		sync_instability_mirror()


func sync_instability_mirror() -> void:
	instability = int(variables.get("instability", 0))


func duplicate_state() -> ChronicaState:
	var copy := ChronicaState.new()
	copy.location = location
	copy.reality_layer = reality_layer
	copy.memory = memory.duplicate(true)
	copy.variables = variables.duplicate(true)
	if not copy.variables.has("instability") and instability != 0:
		copy.variables["instability"] = instability
	copy.sync_instability_mirror()
	return copy
