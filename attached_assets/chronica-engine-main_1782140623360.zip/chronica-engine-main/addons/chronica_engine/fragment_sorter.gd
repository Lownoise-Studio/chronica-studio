class_name FragmentSorter
extends RefCounted


static func compare(a: Fragment, b: Fragment) -> bool:
	if a.priority != b.priority:
		return a.priority > b.priority
	if a.id != b.id:
		return a.id < b.id
	return a.text < b.text
