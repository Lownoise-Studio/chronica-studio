class_name ValidationIssue
extends RefCounted

var severity: String = ""
var code: String = ""
var message: String = ""
var fragment_id: String = ""


func _init(
	p_severity: String = "",
	p_code: String = "",
	p_message: String = "",
	p_fragment_id: String = ""
) -> void:
	severity = p_severity
	code = p_code
	message = p_message
	fragment_id = p_fragment_id
