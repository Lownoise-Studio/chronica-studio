class_name Choice
extends Resource

var label: String = ""
var action: String = ""


func _init(p_label: String = "", p_action: String = "") -> void:
	label = p_label
	action = p_action
