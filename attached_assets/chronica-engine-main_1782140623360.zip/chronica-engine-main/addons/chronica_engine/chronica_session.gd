class_name ChronicaSession
extends Node

signal fragment_changed(fragment: Fragment)
signal state_changed(state: ChronicaState)
signal session_loaded(state: ChronicaState)

var state: ChronicaState
var store: FragmentStore = FragmentStore.new()
var resolver: TurnResolver
var serializer: ChronicaSerializer = ChronicaSerializer.new()
var event_bus: ChronicaEventBus = ChronicaEventBus.new()

var _modules: Array[ChronicaModule] = []
var _module_insertion_order: Dictionary = {}
var _next_module_insertion_index: int = 0


func _ready() -> void:
	resolver = TurnResolver.new()
	add_child(resolver)
	resolver.turn_resolved.connect(_on_turn_resolved)


func add_module(module: ChronicaModule) -> void:
	_modules.append(module)
	_module_insertion_order[module] = _next_module_insertion_index
	_next_module_insertion_index += 1
	module.initialize(self)


func start(start_location: String) -> Fragment:
	if state == null:
		state = ChronicaState.new()

	state.location = start_location
	var fragment := get_current_fragment()
	event_bus.emit_event("session_started", {
		"location": start_location,
		"fragment": fragment,
	})
	event_bus.emit_event("fragment_changed", fragment)
	event_bus.emit_event("state_changed", state)
	fragment_changed.emit(fragment)
	state_changed.emit(state)
	return fragment


func choose(choice: Choice) -> Fragment:
	var fragment := resolver.resolve(choice, state, store)
	if fragment == null:
		return null

	event_bus.emit_event("choice_selected", {
		"choice": choice,
		"fragment": fragment,
	})
	event_bus.emit_event("fragment_changed", fragment)
	event_bus.emit_event("state_changed", state)
	fragment_changed.emit(fragment)
	state_changed.emit(state)
	return fragment


func load_fragments(path: String) -> int:
	var fragments := FragmentLoader.load_directory(path)
	store.add_all(fragments)
	return fragments.size()


func save(path: String = "user://save.json") -> bool:
	if state == null:
		return false

	return ChronicaSerializer.save_state(state, path)


func load(path: String = "user://save.json") -> bool:
	var loaded := ChronicaSerializer.load_state(path)
	if loaded == null:
		return false

	state = loaded
	event_bus.emit_event("session_loaded", state)
	event_bus.emit_event("state_changed", state)
	session_loaded.emit(state)
	state_changed.emit(state)
	_notify_session_loaded(state)
	return true


func get_current_fragment() -> Fragment:
	if state == null:
		return null

	return store.get_active_fragment(state.location, state)


func _on_turn_resolved(
	previous_state: ChronicaState,
	current_state: ChronicaState,
	choice: Choice,
	fragment: Fragment
) -> void:
	# Modules run in ascending priority order (lower first). Equal priority preserves
	# add_module() registration order so same-priority modules stay deterministic.
	for module in _modules_sorted_for_turn():
		module.on_turn_resolved(previous_state, current_state, choice, fragment)


func _modules_sorted_for_turn() -> Array[ChronicaModule]:
	var sorted := _modules.duplicate()
	sorted.sort_custom(
		func(a: ChronicaModule, b: ChronicaModule) -> bool:
			if a.priority != b.priority:
				return a.priority < b.priority
			return int(_module_insertion_order.get(a, 0)) < int(_module_insertion_order.get(b, 0))
	)
	return sorted


func _notify_session_loaded(loaded_state: ChronicaState) -> void:
	for module in _modules:
		module.on_session_loaded(loaded_state)
