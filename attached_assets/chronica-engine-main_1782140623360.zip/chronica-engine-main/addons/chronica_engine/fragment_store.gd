class_name FragmentStore
extends RefCounted

var _fragments: Array[Fragment] = []


func add(fragment: Fragment) -> void:
	_fragments.append(fragment)


func add_all(fragments: Array[Fragment]) -> void:
	for fragment in fragments:
		add(fragment)


func get_active_fragment(location: String, state: ChronicaState) -> Fragment:
	var matches: Array[Fragment] = []

	for fragment in _fragments:
		if fragment.id != location:
			continue
		if not fragment.is_valid(state):
			continue
		matches.append(fragment)

	if matches.is_empty():
		return null

	matches.sort_custom(FragmentSorter.compare)

	return matches[0]
