class_name ChronicaSerializer
extends RefCounted


static func state_to_dict(state: ChronicaState) -> Dictionary:
	var canonical_instability := int(state.get_var("instability", state.instability))
	return {
		"location": state.location,
		"instability": canonical_instability,
		"reality_layer": state.reality_layer,
		"memory": state.memory.duplicate(true),
		"variables": state.variables.duplicate(true),
	}


static func state_from_dict(data: Dictionary) -> ChronicaState:
	var state := ChronicaState.new()
	state.location = str(data.get("location", ""))
	state.instability = int(data.get("instability", 0))
	state.reality_layer = int(data.get("reality_layer", 0))

	var memory: Variant = data.get("memory", {})
	if memory is Dictionary:
		state.memory = _normalize_dictionary(memory)
	else:
		state.memory = {}

	var variables: Variant = data.get("variables", {})
	if variables is Dictionary:
		state.variables = _normalize_dictionary(variables)
	else:
		state.variables = {}

	if state.variables.has("instability"):
		state.sync_instability_mirror()
	elif state.instability != 0:
		state.set_var("instability", state.instability)
	else:
		state.sync_instability_mirror()

	return state


static func _normalize_dictionary(values: Dictionary) -> Dictionary:
	var normalized := {}
	for key in values:
		normalized[key] = _normalize_value(values[key])
	return normalized


static func _normalize_value(value: Variant) -> Variant:
	if value is float and value == floor(value):
		return int(value)
	return value


static func save_state(state: ChronicaState, path: String) -> bool:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("Failed to open file for writing: %s" % path)
		return false

	file.store_string(JSON.stringify(state_to_dict(state), "\t"))
	return true


static func load_state(path: String) -> ChronicaState:
	if not FileAccess.file_exists(path):
		push_error("Save file not found: %s" % path)
		return null

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("Failed to open file for reading: %s" % path)
		return null

	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed == null or not parsed is Dictionary:
		push_error("Invalid save file format: %s" % path)
		return null

	return state_from_dict(parsed)
