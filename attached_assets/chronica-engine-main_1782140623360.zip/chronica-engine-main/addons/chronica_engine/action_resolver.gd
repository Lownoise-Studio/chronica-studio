class_name ActionResolver
extends RefCounted


static func resolve(action: String, state: ChronicaState) -> void:
	var trimmed := action.strip_edges()
	if trimmed.is_empty():
		return

	if trimmed.begins_with("goto:"):
		state.location = trimmed.substr(5)
		return

	if trimmed.contains("+="):
		ExpressionEvaluator.apply_effect(trimmed, state)
		return

	if trimmed.contains("="):
		ExpressionEvaluator.apply_effect(trimmed, state)
		return

	push_error("Unsupported action: %s" % action)
