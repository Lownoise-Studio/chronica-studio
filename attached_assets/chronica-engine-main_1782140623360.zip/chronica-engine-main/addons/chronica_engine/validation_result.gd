class_name ValidationResult
extends RefCounted

var issues: Array[ValidationIssue] = []


func add_error(code: String, message: String, fragment_id: String = "") -> void:
	issues.append(ValidationIssue.new("error", code, message, fragment_id))


func add_warning(code: String, message: String, fragment_id: String = "") -> void:
	issues.append(ValidationIssue.new("warning", code, message, fragment_id))


func has_errors() -> bool:
	for issue in issues:
		if issue.severity == "error":
			return true
	return false


func has_warnings() -> bool:
	for issue in issues:
		if issue.severity == "warning":
			return true
	return false


func sort_issues() -> void:
	issues.sort_custom(func(a: ValidationIssue, b: ValidationIssue) -> bool:
		if a.severity != b.severity:
			return a.severity == "error"
		if a.code != b.code:
			return a.code < b.code
		if a.fragment_id != b.fragment_id:
			return a.fragment_id < b.fragment_id
		return a.message < b.message
	)
